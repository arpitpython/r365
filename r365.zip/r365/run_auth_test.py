"""
run_auth_test.py — Login + GL Account Detail Export download.

First-time setup (saves password to OS keychain):
    python -m app.credentials setup

Run the export:
    python run_auth_test.py
    python run_auth_test.py --start 2025-01-01 --end 2025-12-31
    python run_auth_test.py --start 2025-01-01 --end 2025-12-31 --out ./downloads/q1.xlsx
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import date, datetime
from pathlib import Path

from app.auth import R365Authenticator
from app.config import TENANTS
from app.credentials import CredentialManager
from app.exceptions import AuthError, ReportError
from app.reports import GLAccountDetailExporter
from app.types import ReportRequest


def parse_args() -> argparse.Namespace:
    today = date.today()
    p = argparse.ArgumentParser(description="R365 GL Account Detail Export")
    p.add_argument("--start", default="2025-01-01", help="Start date YYYY-MM-DD")
    p.add_argument("--end",   default=today.strftime("%Y-%m-%d"), help="End date YYYY-MM-DD")
    p.add_argument("--out",   default="./downloads/GL_Account_Detail_Export.xlsx")
    return p.parse_args()


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stdout,
    )
    logger = logging.getLogger(__name__)
    args = parse_args()

    try:
        start_date = datetime.strptime(args.start, "%Y-%m-%d").date()
        end_date   = datetime.strptime(args.end,   "%Y-%m-%d").date()
    except ValueError as exc:
        logger.error("Invalid date: %s", exc)
        sys.exit(1)

    if start_date > end_date:
        logger.error("start (%s) must be before end (%s).", start_date, end_date)
        sys.exit(1)

    # ── Resolve tenant + credential ────────────────────────────────────────
    tenant     = TENANTS["fortisfranchise"]
    credential = tenant.default_credential()
    if not credential:
        logger.error("No credentials configured.")
        sys.exit(1)

    # Verify the password is stored before we start the network flow
    if not CredentialManager.has_password(credential.username):
        logger.error(
            "No password stored for user '%s'. "
            "Run setup first:  python -m app.credentials setup",
            credential.username,
        )
        sys.exit(1)

    logger.info("=" * 60)
    logger.info("Tenant  : %s", tenant.name)
    logger.info("User    : %s (%s)", credential.display_name, credential.username)
    logger.info("Report  : GL Account Detail Export")
    logger.info("Period  : %s to %s", start_date, end_date)
    logger.info("Output  : %s", args.out)
    logger.info("=" * 60)

    # ── Login ──────────────────────────────────────────────────────────────
    try:
        auth_result = R365Authenticator(tenant, credential).login()
    except AuthError as exc:
        logger.error("Login failed — %s: %s", type(exc).__name__, exc)
        sys.exit(1)

    logger.info("Login successful. User ID: %s", auth_result.user_id)

    # ── Download report ────────────────────────────────────────────────────
    # GLAccountDetailExporter now handles ReportsPage + ValidateReport
    # internally — no sql_server / tz_code / utc_offset needed here.
    exporter = GLAccountDetailExporter(
        session=auth_result.session,
        tenant_host=auth_result.tenant_host,
        user_id=auth_result.user_id,
    )

    try:
        result = exporter.download(ReportRequest(
            start_date=start_date,
            end_date=end_date,
            output_path=args.out,
        ))
    except ReportError as exc:
        logger.error("Report failed — %s: %s", type(exc).__name__, exc)
        sys.exit(1)

    logger.info("=" * 60)
    logger.info("Report downloaded successfully!")
    logger.info("  File   : %s", Path(result.saved_path).resolve())
    logger.info("  Size   : %.1f KB", result.file_size_bytes / 1024)
    logger.info("  Period : %s to %s", result.start_date, result.end_date)
    logger.info("=" * 60)


if __name__ == "__main__":
    main()