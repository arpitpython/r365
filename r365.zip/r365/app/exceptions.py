"""
Custom exceptions for the R365 desktop tool.

Single responsibility:
- Typed exceptions for authentication, OIDC, and report download failures.
"""

from __future__ import annotations


# ─────────────────────────────────────────────
#  Auth exceptions
# ─────────────────────────────────────────────

class AuthError(Exception):
    """Base exception for authentication failures."""


class InvalidCredentialsError(AuthError):
    """Username or password is invalid."""


class MfaRequiredError(AuthError):
    """MFA challenge detected. Non-interactive login is not supported for MFA accounts."""


class AntiForgeryTokenNotFound(AuthError):
    """__RequestVerificationToken hidden field not found on the login page."""


class UpstreamChangedError(AuthError):
    """Upstream HTML/flow changed and parser assumptions failed."""


class OidcCallbackError(AuthError):
    """
    The OIDC form_post callback to /NetCore/signin-oidc failed.
    Possible causes: expired code, state mismatch, tenant rejected the exchange.
    """


class SessionVerificationError(AuthError):
    """Could not verify an authenticated session after completing the OIDC flow."""


# ─────────────────────────────────────────────
#  Report exceptions
# ─────────────────────────────────────────────

class ReportError(Exception):
    """Base exception for report download failures."""


class ReportExportFailed(ReportError):
    """The server returned an error or unexpected response from RunAndExport."""


class ReportDownloadFailed(ReportError):
    """Could not download the report file from the Azure Blob Storage URL."""