# r365_desktop/app/config.py
"""
Configuration and constants for the R365 desktop tool.

Passwords are NEVER stored here.  Use the setup wizard to save them
securely in the OS keychain:

    python -m app.credentials setup

Then retrieve at runtime with:

    from app.credentials import CredentialManager
    password = CredentialManager.get_password(username)

The fields sql_server, tz_code, and utc_offset have been removed from
Credential — they are now resolved live from ValidateReport on every run,
so they always reflect the current tenant configuration.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass(frozen=True)
class Settings:
    identity_host: str = os.getenv("R365_IDENTITY_HOST", "identity.restaurant365.com")
    default_user_agent: str = os.getenv(
        "R365_USER_AGENT",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    )
    request_timeout_seconds: int = int(os.getenv("R365_TIMEOUT_SECONDS", "30"))
    report_timeout_seconds: int = int(os.getenv("R365_REPORT_TIMEOUT_SECONDS", "180"))
    max_retries: int = int(os.getenv("R365_MAX_RETRIES", "3"))
    backoff_factor: float = float(os.getenv("R365_BACKOFF_FACTOR", "0.5"))
    verify_tls: bool = os.getenv("R365_VERIFY_TLS", "true").lower() == "true"


@dataclass(frozen=True)
class Credential:
    """
    A single R365 user credential.

    username     — R365 login username.
    user_id      — Permanent UUID for this account (never changes).
                   Find it: browser DevTools → Application → Cookies → userId
    display_name — Full name shown in the UI (used for injected cookies).

    NOTE: The password is NOT stored here.  It lives in the OS keychain.
          Call CredentialManager.get_password(username) to retrieve it,
          or run `python -m app.credentials setup` to store it initially.

    NOTE: sql_server, tz_code, and utc_offset are no longer stored here.
          They are resolved dynamically via ValidateReport on every run.
    """
    username: str
    user_id: str
    display_name: str

    def get_password(self) -> str:
        """Fetch this credential's password from the OS keychain."""
        from .credentials import CredentialManager
        return CredentialManager.get_password(self.username)


@dataclass(frozen=True)
class Tenant:
    name: str
    subdomain_host: str
    app_path: str = "AKS"
    credentials: Dict[str, Credential] = field(default_factory=dict)

    def get_credential(self, username: str) -> Optional[Credential]:
        return self.credentials.get(username)

    def default_credential(self) -> Optional[Credential]:
        if self.credentials:
            return next(iter(self.credentials.values()))
        return None

    @property
    def slug(self) -> str:
        """e.g. 'fortisfranchise' from 'fortisfranchise.restaurant365.com'"""
        return self.subdomain_host.split(".", 1)[0]


def load_tenants() -> Dict[str, Tenant]:
    return {
        "fortisfranchise": Tenant(
            name="Fortis Franchise",
            subdomain_host="fortisfranchise.restaurant365.com",
            app_path="AKS",
            credentials={
                "AnalytixFFG": Credential(
                    username="AnalytixFFG",
                    user_id="60f197ae-795f-4fba-b683-7d01e950dcc8",
                    display_name="Analytix Accounting",
                ),
            },
        ),
    }


SETTINGS = Settings()
TENANTS = load_tenants()

# OIDC constants
CLIENT_ID             = os.getenv("R365_CLIENT_ID", "netcore-signin-opaque")
SCOPES                = os.getenv("R365_SCOPES", "openid profile offline_access")
RESPONSE_TYPE         = os.getenv("R365_RESPONSE_TYPE", "code")
RESPONSE_MODE         = os.getenv("R365_RESPONSE_MODE", "form_post")
CODE_CHALLENGE_METHOD = os.getenv("R365_CODE_CHALLENGE_METHOD", "S256")


def build_acr_values(tenant_slug: str) -> str:
    return (
        f"tenant:{tenant_slug} sso:False unified:true "
        f"loginSso:False authentication_flow:standard"
    )