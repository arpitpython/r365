"""
Typed models used across the R365 desktop tool.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional, Dict
import requests


# ─────────────────────────────────────────────
#  Auth types
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class AuthInputs:
    """Credentials for login — references a username key in the tenant's credential map."""
    tenant_slug: str
    username: str
    password: str


@dataclass(frozen=True)
class AuthResult:
    """Outcome from a successful authentication."""
    session: requests.Session
    tenant_host: str
    final_url: str
    cookies: Dict[str, str]
    user_id: str   # Permanent UUID for this R365 account


@dataclass(frozen=True)
class LoginFormInfo:
    """Parsed login form structure from the Identity login page."""
    action_url: str
    hidden_fields: Dict[str, str]
    username_field: str
    password_field: str
    submit_field: Optional[str] = None
    submit_value: Optional[str] = None


@dataclass(frozen=True)
class LoginPage:
    login_url: str
    form: LoginFormInfo


@dataclass(frozen=True)
class OidcFormPost:
    """OIDC form_post payload returned by IdentityServer after credential acceptance."""
    action_url: str
    fields: Dict[str, str]


# ─────────────────────────────────────────────
#  Report types
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class ReportRequest:
    """Parameters for a report run."""
    start_date: date
    end_date: date
    output_path: str


@dataclass(frozen=True)
class ReportResult:
    """Outcome of a successful report download."""
    report_name: str
    start_date: date
    end_date: date
    saved_path: str
    file_size_bytes: int