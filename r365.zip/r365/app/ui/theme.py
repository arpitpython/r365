"""
R365 Utility — UI theme constants.

Single source of truth for colours, spacing, and typography.
Import this module everywhere instead of hardcoding values.
"""

import flet as ft

# ── Window ─────────────────────────────────────────────────────────────────
WINDOW_WIDTH: int = 780
WINDOW_HEIGHT: int = 640
WINDOW_MIN_WIDTH: int = 640
WINDOW_MIN_HEIGHT: int = 520

# ── Brand colours ──────────────────────────────────────────────────────────
COLOR_PRIMARY: str = ft.Colors.BLUE_700
COLOR_PRIMARY_LIGHT: str = ft.Colors.BLUE_50
COLOR_SURFACE: str = ft.Colors.WHITE
COLOR_BG: str = ft.Colors.GREY_100

# Status colours
COLOR_SUCCESS: str = ft.Colors.GREEN_700
COLOR_WARNING: str = ft.Colors.ORANGE_700
COLOR_ERROR: str = ft.Colors.RED_700
COLOR_INFO: str = ft.Colors.BLUE_600

# Text colours
COLOR_TEXT_PRIMARY: str = ft.Colors.GREY_900
COLOR_TEXT_SECONDARY: str = ft.Colors.GREY_600
COLOR_TEXT_HINT: str = ft.Colors.GREY_400

# Log panel colours
COLOR_LOG_BG: str = ft.Colors.GREY_900
COLOR_LOG_INFO: str = ft.Colors.GREY_300
COLOR_LOG_WARNING: str = ft.Colors.ORANGE_300
COLOR_LOG_ERROR: str = ft.Colors.RED_300
COLOR_LOG_CRITICAL: str = ft.Colors.RED_400
COLOR_LOG_SUCCESS: str = ft.Colors.GREEN_400  # custom app messages

# ── Spacing ────────────────────────────────────────────────────────────────
SPACING_XS: int = 4
SPACING_SM: int = 8
SPACING_MD: int = 16
SPACING_LG: int = 24
SPACING_XL: int = 32

PAD_PAGE = ft.padding.all(SPACING_LG)
PAD_CARD = ft.padding.all(SPACING_MD)
PAD_SECTION = ft.padding.symmetric(horizontal=SPACING_LG, vertical=SPACING_MD)

# ── Typography ─────────────────────────────────────────────────────────────
SIZE_TITLE: int = 22
SIZE_HEADING: int = 16
SIZE_BODY: int = 14
SIZE_SMALL: int = 12
SIZE_LOG: int = 12

# ── Shape ──────────────────────────────────────────────────────────────────
RADIUS_CARD: int = 10
RADIUS_BUTTON: int = 6
RADIUS_INPUT: int = 6

# ── Input widths ───────────────────────────────────────────────────────────
WIDTH_INPUT_SM: int = 140
WIDTH_INPUT_MD: int = 240
WIDTH_INPUT_LG: int = 320

# ── Log panel ──────────────────────────────────────────────────────────────
LOG_MAX_LINES: int = 200   # oldest lines dropped beyond this
LOG_PANEL_HEIGHT: int = 220