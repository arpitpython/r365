"""
R365 Utility — Flet logging handler.

Bridges the standard Python ``logging`` module into the Flet UI.
Attach one ``FletLogHandler`` per screen that shows a log panel;
it translates log levels into human-readable coloured lines and
appends them to a scrollable ``ft.Column`` in real time.

**Threading design**

The download runs on a background thread and produces many log records in
rapid succession.  Calling ``page.update()`` on every single record causes
a WebSocket round-trip to the renderer for each one, which freezes the UI.

Instead, incoming records are buffered in ``_pending``.  A one-shot
``threading.Timer`` fires after ``_FLUSH_INTERVAL`` seconds and flushes all
buffered records in a single ``page.update()`` call.  Status/app messages
(e.g. "Login successful") bypass the buffer and are flushed immediately so
important milestones appear without delay.

Usage::

    handler = FletLogHandler(page, log_column)
    logging.getLogger().addHandler(handler)
    # … later, to detach:
    logging.getLogger().removeHandler(handler)
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING

import flet as ft

from app.ui import theme

if TYPE_CHECKING:
    pass

# Human-readable prefixes shown in the log panel
_LEVEL_PREFIX: dict[int, str] = {
    logging.DEBUG:    "DEBUG",
    logging.INFO:     "INFO ",
    logging.WARNING:  "WARN ",
    logging.ERROR:    "ERROR",
    logging.CRITICAL: "CRIT ",
}

# Colour per level (matches theme constants)
_LEVEL_COLOR: dict[int, str] = {
    logging.DEBUG:    theme.COLOR_LOG_INFO,
    logging.INFO:     theme.COLOR_LOG_INFO,
    logging.WARNING:  theme.COLOR_LOG_WARNING,
    logging.ERROR:    theme.COLOR_LOG_ERROR,
    logging.CRITICAL: theme.COLOR_LOG_CRITICAL,
}

# Noisy internal loggers we suppress in the UI panel
_SUPPRESSED_LOGGERS: frozenset[str] = frozenset({
    "urllib3",
    "urllib3.connectionpool",
    "requests",
    "charset_normalizer",
})

# How often the buffered log lines are flushed to the UI (seconds).
# Lower = more responsive; higher = fewer page.update() calls.
_FLUSH_INTERVAL = 0.15


class FletLogHandler(logging.Handler):
    """
    A ``logging.Handler`` that appends coloured ``ft.Text`` rows to a
    ``ft.Column``, batching UI updates to keep the Flet UI responsive.

    Args:
        page:       The active Flet page (for ``page.update()``).
        log_col:    The ``ft.Column`` that acts as the log panel body.
        max_lines:  Maximum number of lines to keep (oldest are dropped).
    """

    def __init__(
        self,
        page: ft.Page,
        log_col: ft.Column,
        max_lines: int = theme.LOG_MAX_LINES,
    ) -> None:
        super().__init__()
        self._page      = page
        self._log_col   = log_col
        self._max_lines = max_lines
        self._lock      = threading.Lock()

        # Buffer for incoming log records between flush cycles
        self._pending: list[ft.Text] = []
        self._flush_timer: threading.Timer | None = None

        # Format: "INFO  | some.module: message"
        self.setFormatter(
            logging.Formatter("%(levelname)-5s | %(name)s: %(message)s")
        )

    # ------------------------------------------------------------------
    # logging.Handler interface
    # ------------------------------------------------------------------

    def emit(self, record: logging.LogRecord) -> None:
        """Buffer one log line; schedule a UI flush if not already pending."""
        if record.name.split(".")[0] in _SUPPRESSED_LOGGERS:
            return

        try:
            msg = self.format(record)
        except Exception:  # noqa: BLE001
            msg = record.getMessage()

        color = _LEVEL_COLOR.get(record.levelno, theme.COLOR_LOG_INFO)
        row = ft.Text(
            value=msg,
            size=theme.SIZE_LOG,
            color=color,
            selectable=True,
            font_family="monospace",
            no_wrap=True,
        )

        with self._lock:
            self._pending.append(row)
            # Schedule a flush if one isn't already queued
            if self._flush_timer is None:
                self._flush_timer = threading.Timer(_FLUSH_INTERVAL, self._flush)
                self._flush_timer.daemon = True
                self._flush_timer.start()

    # ------------------------------------------------------------------
    # Internal flush
    # ------------------------------------------------------------------

    def _flush(self) -> None:
        """
        Move all pending rows into the log column and call page.update() once.
        Called by the timer thread — never call directly from emit().
        """
        with self._lock:
            if not self._pending:
                self._flush_timer = None
                return
            self._log_col.controls.extend(self._pending)
            self._pending.clear()
            # Cap the number of displayed lines to avoid unbounded growth
            if len(self._log_col.controls) > self._max_lines:
                self._log_col.controls = (
                    self._log_col.controls[-self._max_lines:]
                )
            self._flush_timer = None

        try:
            self._page.update()
        except Exception:  # noqa: BLE001
            # Page may have been closed — ignore silently
            pass

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def add_app_message(
        self,
        message: str,
        level: str = "info",
    ) -> None:
        """
        Append a plain human-readable status message immediately (no buffer).

        Use this for important milestones ("Login successful", "Download
        failed") where the user should see the update without delay.

        Args:
            message: Text to display.
            level:   One of ``"info"``, ``"success"``, ``"warning"``,
                     ``"error"``.
        """
        color_map = {
            "info":    theme.COLOR_LOG_INFO,
            "success": theme.COLOR_LOG_SUCCESS,
            "warning": theme.COLOR_LOG_WARNING,
            "error":   theme.COLOR_LOG_ERROR,
        }
        color = color_map.get(level, theme.COLOR_LOG_INFO)

        row = ft.Text(
            value=f"  ▶  {message}",
            size=theme.SIZE_LOG,
            color=color,
            selectable=True,
            no_wrap=True,
        )

        with self._lock:
            self._log_col.controls.append(row)

        try:
            self._page.update()
        except Exception:  # noqa: BLE001
            pass

    def clear(self) -> None:
        """Remove all lines (pending and displayed) from the log panel."""
        with self._lock:
            # Cancel any in-flight flush timer
            if self._flush_timer is not None:
                self._flush_timer.cancel()
                self._flush_timer = None
            self._pending.clear()
            self._log_col.controls.clear()

        try:
            self._page.update()
        except Exception:  # noqa: BLE001
            pass
