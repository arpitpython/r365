"""
R365 Utility — application entry point.

Sets up the Flet page, shows a loading splash immediately, then detects
whether credentials exist in a background thread before routing to the
login or report screen.

Run with::

    python -m app.ui.app
"""

from __future__ import annotations

import logging

import flet as ft

from app.credentials import CredentialManager
from app.config import TENANTS
from app.ui import theme
from app.ui.view.login_view import LoginView
from app.ui.view.report_view import ReportView

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------

def _show_login(page: ft.Page) -> None:
    """Navigate to the login / credential setup screen."""
    page.controls.clear()
    view = LoginView(
        page=page,
        on_connect=lambda tenant_slug, username: _show_report(
            page, tenant_slug, username
        ),
    )
    page.controls.append(view.build())
    page.update()


def _show_report(page: ft.Page, tenant_slug: str, username: str) -> None:
    """Navigate to the GL report download screen."""
    page.controls.clear()
    page.update()

    view = ReportView(
        page=page,
        tenant_slug=tenant_slug,
        username=username,
        on_sign_out=lambda: _show_login(page),
    )
    page.controls.append(view.build())
    page.update()


def _show_loading(page: ft.Page) -> None:
    """
    Splash screen shown while the background credential check runs.

    Displayed immediately so the window is never blank — keyring calls
    can take 1-2 seconds on Windows, which would otherwise freeze the UI.
    """
    page.controls.clear()
    page.controls.append(
        ft.Container(
            expand=True,
            bgcolor=theme.COLOR_BG,
            content=ft.Column(
                expand=True,
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=theme.SPACING_MD,
                controls=[
                    ft.Icon(
                        ft.Icons.BUSINESS,
                        size=48,
                        color=theme.COLOR_PRIMARY,
                    ),
                    ft.Text(
                        "R365 Utility",
                        size=theme.SIZE_TITLE,
                        weight=ft.FontWeight.BOLD,
                        color=theme.COLOR_TEXT_PRIMARY,
                    ),
                    ft.Container(height=8),
                    ft.ProgressRing(color=theme.COLOR_PRIMARY),
                ],
            ),
        )
    )
    page.update()


# ---------------------------------------------------------------------------
# Credential detection (runs on a background thread)
# ---------------------------------------------------------------------------

def _find_saved_credential() -> tuple[str, str] | None:
    """
    Return ``(tenant_slug, username)`` for the first credential that has a
    password stored in the OS keychain, or ``None``.

    This may block for 1-2 s on Windows (Credential Manager I/O) — always
    call from a background thread, never from the Flet UI thread.
    """
    for tenant_slug, tenant in TENANTS.items():
        for username in tenant.credentials:
            if CredentialManager.has_password(username):
                return tenant_slug, username
    return None


def _startup_route(page: ft.Page) -> None:
    """
    Background thread entry point.

    Detects saved credentials then navigates to the correct first screen.
    Called via ``page.run_thread()`` so it never blocks the UI thread.
    """
    saved = _find_saved_credential()
    if saved:
        tenant_slug, username = saved
        logger.info(
            "Saved credential found for %s — routing to report screen.",
            username,
        )
        _show_report(page, tenant_slug, username)
    else:
        logger.info("No saved credential found — showing login screen.")
        _show_login(page)


# ---------------------------------------------------------------------------
# Flet entry point
# ---------------------------------------------------------------------------

def main(page: ft.Page) -> None:
    """Flet main function — called once per app launch."""
    # ── Page configuration ──────────────────────────────────────────────
    page.title = "R365 Utility"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 0
    page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
    page.bgcolor = theme.COLOR_BG
    page.window_width = theme.WINDOW_WIDTH
    page.window_height = theme.WINDOW_HEIGHT
    page.window_min_width = theme.WINDOW_MIN_WIDTH
    page.window_min_height = theme.WINDOW_MIN_HEIGHT

    # ── Show splash immediately so the window is never blank ────────────
    _show_loading(page)

    # ── Detect credentials in background — keyring I/O can be slow ──────
    page.run_thread(_startup_route, page)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    ft.run(main)
