"""
R365 Utility — Login / credential setup view.

Shown on first launch (no password stored) or when the user
explicitly signs out.  Handles:

  - Detecting whether a password is already saved in the OS keychain
  - Username dropdown (populated from config)
  - Password field (secure input)
  - "Save & Connect" button — stores to keychain then triggers login
  - Error display below the form
"""

from __future__ import annotations

import logging
from typing import Callable

import flet as ft

from app.config import TENANTS
from app.credentials import CredentialManager
from app.ui import theme

logger = logging.getLogger(__name__)

# Collect all (tenant_slug, credential) pairs from config
_ALL_CREDENTIALS = [
    (tenant_slug, cred)
    for tenant_slug, tenant in TENANTS.items()
    for cred in tenant.credentials.values()
]


class LoginView:
    """
    Login screen.

    Args:
        page:        The active Flet page.
        on_connect:  Callback invoked with ``(tenant_slug, username)``
                     when the user has valid credentials and clicks
                     "Save & Connect".
    """

    def __init__(
        self,
        page: ft.Page,
        on_connect: Callable[[str, str], None],
    ) -> None:
        self._page = page
        self._on_connect = on_connect

        # ── State ──────────────────────────────────────────────────────
        # Build dropdown options from all configured credentials
        self._dropdown_options = [
            ft.DropdownOption(
                key=f"{tenant_slug}|{cred.username}",
                text=f"{cred.display_name}  ({cred.username})",
            )
            for tenant_slug, cred in _ALL_CREDENTIALS
        ]
        # Pre-select the first option
        self._initial_key = (
            self._dropdown_options[0].key
            if self._dropdown_options
            else None
        )

        # ── Controls (built once, mutated on events) ───────────────────
        # Flet 0.82.x Dropdown: on_change must be set as an
        # attribute after construction; hint_text not supported
        # on the M3 Dropdown (use label only).
        self._user_dd = ft.Dropdown(
            label="Account",
            value=self._initial_key,
            options=self._dropdown_options,
            width=theme.WIDTH_INPUT_LG,
        )
        self._user_dd.on_change = self._on_user_changed

        self._password_field = ft.TextField(
            label="R365 Password",
            hint_text="Enter your R365 password",
            password=True,
            can_reveal_password=True,
            width=theme.WIDTH_INPUT_LG,
            on_submit=self._on_save_connect,
        )

        self._status_text = ft.Text(
            value="",
            size=theme.SIZE_SMALL,
            color=theme.COLOR_ERROR,
        )

        self._connect_btn = ft.ElevatedButton(
            content=ft.Row(
                spacing=8,
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    ft.Icon(ft.Icons.LOGIN, color=ft.Colors.WHITE),
                    ft.Text("Save & Connect", color=ft.Colors.WHITE),
                ],
            ),
            on_click=self._on_save_connect,
            bgcolor=theme.COLOR_PRIMARY,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(
                    radius=theme.RADIUS_BUTTON
                ),
            ),
        )

        self._progress = ft.ProgressBar(
            visible=False,
            width=theme.WIDTH_INPUT_LG,
        )

        # Pre-fill password hint if already stored
        self._prefill_password_hint()

    # ── Public ─────────────────────────────────────────────────────────

    def build(self) -> ft.Control:
        """Return the root control for this view."""
        return ft.Container(
            expand=True,
            bgcolor=theme.COLOR_BG,
            content=ft.Column(
                expand=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=0,
                controls=[
                    self._build_header(),
                    ft.Container(height=theme.SPACING_XL),
                    self._build_card(),
                ],
            ),
        )

    # ── Private — build helpers ─────────────────────────────────────────

    def _build_header(self) -> ft.Control:
        return ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=theme.SPACING_SM,
            controls=[
                ft.Icon(
                    ft.Icons.BUSINESS,
                    size=48,
                    color=theme.COLOR_PRIMARY,
                ),
                ft.Text(
                    value="R365 Utility",
                    size=theme.SIZE_TITLE,
                    weight=ft.FontWeight.BOLD,
                    color=theme.COLOR_TEXT_PRIMARY,
                ),
                ft.Text(
                    value="Restaurant365 report automation",
                    size=theme.SIZE_BODY,
                    color=theme.COLOR_TEXT_SECONDARY,
                ),
            ],
        )

    def _build_card(self) -> ft.Control:
        return ft.Card(
            elevation=3,
            shape=ft.RoundedRectangleBorder(radius=theme.RADIUS_CARD),
            content=ft.Container(
                width=420,
                padding=ft.padding.symmetric(
                    horizontal=theme.SPACING_XL,
                    vertical=theme.SPACING_LG,
                ),
                content=ft.Column(
                    spacing=theme.SPACING_MD,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Text(
                            value="Sign In",
                            size=theme.SIZE_HEADING,
                            weight=ft.FontWeight.W_600,
                            color=theme.COLOR_TEXT_PRIMARY,
                        ),
                        ft.Divider(height=1),
                        self._user_dd,
                        self._password_field,
                        self._status_text,
                        self._progress,
                        ft.Container(height=theme.SPACING_XS),
                        self._connect_btn,
                        ft.Container(height=theme.SPACING_XS),
                        ft.Text(
                            value=(
                                "Your password is saved securely in "
                                "the OS keychain."
                            ),
                            size=theme.SIZE_SMALL,
                            color=theme.COLOR_TEXT_HINT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ],
                ),
            ),
        )

    # ── Private — logic ─────────────────────────────────────────────────

    def _prefill_password_hint(self) -> None:
        """
        If a password is already stored for the selected user, show
        a placeholder so the user knows they can just click Connect.
        """
        key = self._user_dd.value
        if not key:
            return
        username = key.split("|", 1)[1]
        if CredentialManager.has_password(username):
            self._password_field.hint_text = (
                "Password saved — leave blank to use stored password"
            )

    def _on_user_changed(self, _e: ft.ControlEvent) -> None:
        """Update password hint when user selects a different account."""
        self._status_text.value = ""
        self._prefill_password_hint()
        self._page.update()

    def _set_loading(self, loading: bool) -> None:
        self._connect_btn.disabled = loading
        self._user_dd.disabled = loading
        self._password_field.disabled = loading
        self._progress.visible = loading
        self._page.update()

    def _set_error(self, message: str) -> None:
        self._status_text.value = message
        self._status_text.color = theme.COLOR_ERROR
        self._set_loading(False)

    def _on_save_connect(self, _e: ft.ControlEvent) -> None:
        """Validate inputs, save password if provided, invoke callback."""
        self._status_text.value = ""
        self._page.update()

        key = self._user_dd.value
        if not key:
            self._set_error("Please select an account.")
            return

        tenant_slug, username = key.split("|", 1)
        entered_password = self._password_field.value or ""

        # If a new password was entered, save it
        if entered_password.strip():
            try:
                CredentialManager.save_password(
                    username, entered_password.strip()
                )
                logger.info(
                    "Password saved to OS keychain for user: %s",
                    username,
                )
            except Exception as exc:  # noqa: BLE001
                self._set_error(f"Could not save password: {exc}")
                return

        # Verify we now have a stored password
        if not CredentialManager.has_password(username):
            self._set_error(
                "No password saved for this account.  "
                "Please enter your R365 password above."
            )
            return

        self._set_loading(True)
        # Hand off to the app — it will navigate to the report screen
        self._on_connect(tenant_slug, username)