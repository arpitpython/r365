"""
R365 Utility — Report download view.

Shown after successful login.  Allows the user to:

  - Select start / end date via date-picker dialogs
  - Choose a save location for the downloaded .xlsx file
  - Download the GL Account Detail Export report
  - Monitor progress via a live log panel
  - Sign out (returns to the login screen)
"""

from __future__ import annotations

import logging
import os
import subprocess
import threading
import time
from datetime import date
from pathlib import Path
from typing import Callable

import flet as ft

from app.auth import R365Authenticator
from app.config import TENANTS
from app.exceptions import AuthError, ReportError
from app.reports import GLAccountDetailExporter
from app.types import ReportRequest
from app.ui import theme
from app.ui.log_handler import FletLogHandler

logger = logging.getLogger(__name__)

# Default download folder — user's Downloads directory
_DEFAULT_DOWNLOAD_DIR = str(
    Path.home() / "Downloads"
)
_DEFAULT_FILENAME = "GL_Account_Detail_Export.xlsx"


def _pick_folder_windows(initial_dir: str) -> str | None:
    """Open a native Windows folder-browser dialog via PowerShell.

    Returns the selected path, or ``None`` if the user cancelled.
    Runs synchronously — call from a background thread.
    """
    # Escape backslashes for PowerShell string
    safe_dir = initial_dir.replace("\\", "\\\\")
    script = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "$d = New-Object System.Windows.Forms.FolderBrowserDialog; "
        f"$d.SelectedPath = '{safe_dir}'; "
        "$d.Description = 'Choose save folder'; "
        "$null = $d.ShowDialog(); "
        "Write-Output $d.SelectedPath"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True,
            text=True,
            timeout=120,
        )
        path = result.stdout.strip()
        return path if path else None
    except Exception:  # noqa: BLE001
        return None


class ReportView:
    """
    GL Account Detail Export download screen.

    Args:
        page:          The active Flet page.
        tenant_slug:   Selected tenant key (e.g. ``"fortisfranchise"``).
        username:      R365 username of the logged-in credential.
        on_sign_out:   Callback invoked when the user clicks "Sign Out".
    """

    def __init__(
        self,
        page: ft.Page,
        tenant_slug: str,
        username: str,
        on_sign_out: Callable[[], None],
    ) -> None:
        self._page = page
        self._tenant_slug = tenant_slug
        self._username = username
        self._on_sign_out = on_sign_out

        # Resolve config objects
        self._tenant = TENANTS[tenant_slug]
        self._credential = self._tenant.get_credential(username)

        # ── Date state ─────────────────────────────────────────────────
        self._start_date: date = date(date.today().year, 1, 1)
        self._end_date: date = date.today()

        # ── Download timer state ────────────────────────────────────────
        self._download_start_time: float | None = None

        # ── Save-path state ────────────────────────────────────────────
        self._save_path: str = os.path.join(
            _DEFAULT_DOWNLOAD_DIR, _DEFAULT_FILENAME
        )

        # ── Log column (populated by FletLogHandler) ───────────────────
        self._log_col = ft.Column(
            controls=[],
            spacing=2,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
        )

        self._log_handler = FletLogHandler(page, self._log_col)
        # Attach to root logger so all app modules are captured
        logging.getLogger().addHandler(self._log_handler)
        logging.getLogger().setLevel(logging.INFO)

        # ── Date pickers (created once, reused) ────────────────────────
        self._start_picker = ft.DatePicker(
            value=self._start_date,
            on_change=self._on_start_date_picked,
        )
        self._end_picker = ft.DatePicker(
            value=self._end_date,
            on_change=self._on_end_date_picked,
        )

        # ── Controls ───────────────────────────────────────────────────
        self._start_field = ft.TextField(
            value=self._start_date.strftime("%d/%m/%Y"),
            read_only=True,
            width=theme.WIDTH_INPUT_SM,
            text_align=ft.TextAlign.CENTER,
            border_color=theme.COLOR_PRIMARY,
        )
        self._end_field = ft.TextField(
            value=self._end_date.strftime("%d/%m/%Y"),
            read_only=True,
            width=theme.WIDTH_INPUT_SM,
            text_align=ft.TextAlign.CENTER,
            border_color=theme.COLOR_PRIMARY,
        )
        # Read-only save path display (updated by browse button)
        self._save_path_display = ft.Text(
            value=self._save_path,
            size=theme.SIZE_SMALL,
            color=theme.COLOR_TEXT_SECONDARY,
            expand=True,
            no_wrap=True,
            overflow=ft.TextOverflow.ELLIPSIS,
        )
        self._download_btn = ft.ElevatedButton(
            content=ft.Row(
                spacing=8,
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    ft.Icon(ft.Icons.DOWNLOAD, color=ft.Colors.WHITE),
                    ft.Text("Download Report", color=ft.Colors.WHITE),
                ],
            ),
            on_click=self._on_download_clicked,
            bgcolor=theme.COLOR_PRIMARY,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(
                    radius=theme.RADIUS_BUTTON
                ),
            ),
        )
        self._progress_bar = ft.ProgressBar(
            visible=False,
            color=theme.COLOR_PRIMARY,
        )
        self._status_text = ft.Text(
            value="",
            size=theme.SIZE_SMALL,
            color=theme.COLOR_TEXT_SECONDARY,
        )
        self._elapsed_text = ft.Text(
            value="",
            size=theme.SIZE_SMALL,
            color=theme.COLOR_TEXT_HINT,
            visible=False,
        )
        self._clear_log_btn = ft.TextButton(
            content=ft.Row(
                spacing=4,
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    ft.Icon(
                        ft.Icons.DELETE_OUTLINE,
                        color=theme.COLOR_TEXT_HINT,
                        size=16,
                    ),
                    ft.Text(
                        "Clear log",
                        color=theme.COLOR_TEXT_HINT,
                        size=theme.SIZE_SMALL,
                    ),
                ],
            ),
            on_click=self._on_clear_log,
        )
        self._copy_log_btn = ft.TextButton(
            content=ft.Row(
                spacing=4,
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    ft.Icon(
                        ft.Icons.COPY,
                        color=theme.COLOR_TEXT_HINT,
                        size=16,
                    ),
                    ft.Text(
                        "Copy log",
                        color=theme.COLOR_TEXT_HINT,
                        size=theme.SIZE_SMALL,
                    ),
                ],
            ),
            on_click=self._on_copy_log,
        )

    # ── Public ─────────────────────────────────────────────────────────

    def build(self) -> ft.Control:
        """Return the root control for this view."""
        return ft.Container(
            expand=True,
            bgcolor=theme.COLOR_BG,
            padding=theme.PAD_PAGE,
            content=ft.Column(
                expand=True,
                spacing=theme.SPACING_MD,
                controls=[
                    self._build_topbar(),
                    self._build_report_card(),
                    self._progress_bar,
                    self._status_text,
                    self._elapsed_text,
                    self._build_log_panel(),
                ],
            ),
        )

    def detach_logger(self) -> None:
        """Remove the Flet log handler — call before navigating away."""
        logging.getLogger().removeHandler(self._log_handler)

    # ── Private — build helpers ─────────────────────────────────────────

    def _build_topbar(self) -> ft.Control:
        cred = self._credential
        display = (
            cred.display_name if cred else self._username
        )
        return ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Row(
                    spacing=theme.SPACING_SM,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(
                            ft.Icons.BUSINESS,
                            size=22,
                            color=theme.COLOR_PRIMARY,
                        ),
                        ft.Text(
                            value="R365 Utility",
                            size=theme.SIZE_HEADING,
                            weight=ft.FontWeight.BOLD,
                            color=theme.COLOR_TEXT_PRIMARY,
                        ),
                    ],
                ),
                ft.Row(
                    spacing=theme.SPACING_SM,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Icon(
                            ft.Icons.ACCOUNT_CIRCLE_OUTLINED,
                            size=18,
                            color=theme.COLOR_TEXT_SECONDARY,
                        ),
                        ft.Text(
                            value=display,
                            size=theme.SIZE_BODY,
                            color=theme.COLOR_TEXT_SECONDARY,
                        ),
                        ft.TextButton(
                            content=ft.Row(
                                spacing=4,
                                alignment=ft.MainAxisAlignment.CENTER,
                                controls=[
                                    ft.Icon(
                                        ft.Icons.LOGOUT,
                                        color=theme.COLOR_ERROR,
                                        size=16,
                                    ),
                                    ft.Text(
                                        "Sign Out",
                                        color=theme.COLOR_ERROR,
                                        size=theme.SIZE_BODY,
                                    ),
                                ],
                            ),
                            on_click=self._on_sign_out_clicked,
                        ),
                    ],
                ),
            ],
        )

    def _build_report_card(self) -> ft.Control:
        return ft.Card(
            elevation=2,
            shape=ft.RoundedRectangleBorder(radius=theme.RADIUS_CARD),
            content=ft.Container(
                padding=theme.PAD_CARD,
                content=ft.Column(
                    spacing=theme.SPACING_MD,
                    controls=[
                        # Report name header
                        ft.Row(
                            spacing=theme.SPACING_SM,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Icon(
                                    ft.Icons.TABLE_CHART_OUTLINED,
                                    size=20,
                                    color=theme.COLOR_PRIMARY,
                                ),
                                ft.Text(
                                    value="GL Detailed Report",
                                    size=theme.SIZE_HEADING,
                                    weight=ft.FontWeight.W_600,
                                    color=theme.COLOR_TEXT_PRIMARY,
                                ),
                            ],
                        ),
                        ft.Divider(height=1, color=ft.Colors.GREY_200),
                        # Date range row
                        ft.Row(
                            spacing=theme.SPACING_LG,
                            vertical_alignment=ft.CrossAxisAlignment.END,
                            wrap=True,
                            controls=[
                                self._build_date_field(
                                    label="Start Date",
                                    field=self._start_field,
                                    on_pick=self._open_start_picker,
                                ),
                                self._build_date_field(
                                    label="End Date",
                                    field=self._end_field,
                                    on_pick=self._open_end_picker,
                                ),
                            ],
                        ),
                        ft.Divider(height=1, color=ft.Colors.GREY_200),
                        # Save location row
                        self._build_save_location_row(),
                        ft.Divider(height=1, color=ft.Colors.GREY_200),
                        # Download button
                        ft.Row(
                            controls=[self._download_btn],
                        ),
                    ],
                ),
            ),
        )

    def _build_date_field(
        self,
        label: str,
        field: ft.TextField,
        on_pick: Callable,
    ) -> ft.Control:
        return ft.Column(
            spacing=theme.SPACING_XS,
            controls=[
                ft.Text(
                    value=label,
                    size=theme.SIZE_SMALL,
                    color=theme.COLOR_TEXT_SECONDARY,
                    weight=ft.FontWeight.W_500,
                ),
                ft.Row(
                    spacing=theme.SPACING_XS,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        field,
                        ft.IconButton(
                            icon=ft.Icons.CALENDAR_TODAY,
                            icon_color=theme.COLOR_PRIMARY,
                            tooltip=f"Pick {label}",
                            on_click=on_pick,
                        ),
                    ],
                ),
            ],
        )

    def _build_save_location_row(self) -> ft.Control:
        return ft.Column(
            spacing=theme.SPACING_XS,
            controls=[
                ft.Text(
                    value="Save Location",
                    size=theme.SIZE_SMALL,
                    color=theme.COLOR_TEXT_SECONDARY,
                    weight=ft.FontWeight.W_500,
                ),
                ft.Row(
                    spacing=theme.SPACING_SM,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        self._save_path_display,
                        ft.IconButton(
                            icon=ft.Icons.FOLDER_OPEN_OUTLINED,
                            icon_color=theme.COLOR_PRIMARY,
                            tooltip="Browse for folder",
                            on_click=self._on_browse_clicked,
                        ),
                    ],
                ),
            ],
        )

    def _build_log_panel(self) -> ft.Control:
        return ft.Column(
            expand=True,
            spacing=theme.SPACING_XS,
            controls=[
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Text(
                            value="Activity Log",
                            size=theme.SIZE_SMALL,
                            weight=ft.FontWeight.W_600,
                            color=theme.COLOR_TEXT_SECONDARY,
                        ),
                        ft.Row(
                            spacing=0,
                            controls=[
                                self._copy_log_btn,
                                self._clear_log_btn,
                            ],
                        ),
                    ],
                ),
                ft.Container(
                    expand=True,
                    bgcolor=theme.COLOR_LOG_BG,
                    border_radius=theme.RADIUS_CARD,
                    padding=ft.padding.all(theme.SPACING_SM),
                    content=self._log_col,
                    border=ft.border.all(1, ft.Colors.GREY_800),
                ),
            ],
        )

    # ── Private — event handlers ────────────────────────────────────────

    def _open_start_picker(self, _e: ft.ControlEvent) -> None:
        self._start_picker.value = self._start_date
        self._page.show_dialog(self._start_picker)

    def _open_end_picker(self, _e: ft.ControlEvent) -> None:
        self._end_picker.value = self._end_date
        self._page.show_dialog(self._end_picker)

    def _on_start_date_picked(self, _e: ft.ControlEvent) -> None:
        if self._start_picker.value:
            self._start_date = self._start_picker.value
            self._start_field.value = self._start_date.strftime("%d/%m/%Y")
            self._start_field.update()

    def _on_end_date_picked(self, _e: ft.ControlEvent) -> None:
        if self._end_picker.value:
            self._end_date = self._end_picker.value
            self._end_field.value = self._end_date.strftime("%d/%m/%Y")
            self._end_field.update()

    def _on_browse_clicked(self, _e: ft.ControlEvent) -> None:
        """Open a native Windows folder-picker in a background thread."""
        def pick() -> None:
            path = _pick_folder_windows(_DEFAULT_DOWNLOAD_DIR)
            if path:
                self._save_path = os.path.join(path, _DEFAULT_FILENAME)
                self._save_path_display.value = self._save_path
                self._save_path_display.update()

        threading.Thread(target=pick, daemon=True).start()

    def _on_copy_log(self, _e: ft.ControlEvent) -> None:
        """Copy all visible log lines to the clipboard."""
        lines = [
            c.value
            for c in self._log_col.controls
            if isinstance(c, ft.Text) and c.value
        ]
        self._page.run_task(self._set_clipboard_async, "\n".join(lines))

    async def _set_clipboard_async(self, text: str) -> None:
        """Write *text* to the OS clipboard using the Flet 0.80+ Clipboard service."""
        await ft.Clipboard().set(text)

    def _on_clear_log(self, _e: ft.ControlEvent) -> None:
        self._log_handler.clear()

    def _on_sign_out_clicked(self, _e: ft.ControlEvent) -> None:
        if self._download_btn.disabled:
            # Download in progress — ask for confirmation
            def _confirm(ev: ft.ControlEvent) -> None:
                self._page.pop_dialog()
                self._do_sign_out()

            self._page.show_dialog(
                ft.AlertDialog(
                    modal=True,
                    title=ft.Text("Download in progress"),
                    content=ft.Text(
                        "A report download is in progress.  "
                        "Sign out anyway?"
                    ),
                    actions=[
                        ft.TextButton(
                            "Cancel",
                            on_click=lambda e: self._page.pop_dialog(),
                        ),
                        ft.ElevatedButton(
                            "Sign Out",
                            on_click=_confirm,
                        ),
                    ],
                    actions_alignment=ft.MainAxisAlignment.END,
                )
            )
            return
        self._do_sign_out()

    def _do_sign_out(self) -> None:
        self.detach_logger()
        self._on_sign_out()

    # ── Private — download logic ────────────────────────────────────────

    @staticmethod
    def _format_elapsed(seconds: float) -> str:
        """Format elapsed seconds as '1m 23s' or '45s'."""
        s = int(seconds)
        if s >= 60:
            return f"{s // 60}m {s % 60:02d}s"
        return f"{s}s"

    def _set_downloading(self, downloading: bool, status: str = "") -> None:
        self._download_btn.disabled = downloading
        self._progress_bar.visible = downloading
        self._status_text.value = status
        self._status_text.color = theme.COLOR_TEXT_SECONDARY
        if downloading:
            self._elapsed_text.visible = False
        self._page.update()

    def _set_status_success(self, message: str) -> None:
        self._status_text.value = message
        self._status_text.color = theme.COLOR_SUCCESS
        self._download_btn.disabled = False
        self._progress_bar.visible = False
        if self._download_start_time is not None:
            elapsed = time.monotonic() - self._download_start_time
            self._elapsed_text.value = f"Completed in {self._format_elapsed(elapsed)}"
            self._elapsed_text.visible = True
        self._page.update()

    def _set_status_error(self, message: str) -> None:
        self._status_text.value = message
        self._status_text.color = theme.COLOR_ERROR
        self._download_btn.disabled = False
        self._progress_bar.visible = False
        if self._download_start_time is not None:
            elapsed = time.monotonic() - self._download_start_time
            self._elapsed_text.value = f"Failed after {self._format_elapsed(elapsed)}"
            self._elapsed_text.visible = True
        self._page.update()

    def _on_download_clicked(self, _e: ft.ControlEvent) -> None:
        """Validate inputs then kick off the background download."""
        # Validate date range
        if self._start_date > self._end_date:
            self._set_status_error(
                "Start date must be before end date."
            )
            return

        # Validate save path
        save_dir = os.path.dirname(self._save_path)
        if save_dir and not os.path.isdir(save_dir):
            try:
                os.makedirs(save_dir, exist_ok=True)
            except OSError as exc:
                self._set_status_error(
                    f"Cannot create save folder: {exc}"
                )
                return

        self._log_handler.clear()
        self._download_start_time = time.monotonic()
        self._set_downloading(True, "Starting — please wait…")
        self._page.run_thread(self._run_download)

    def _run_download(self) -> None:
        """
        Background thread: authenticate then download the report.

        Never called on the UI thread — safe to do long blocking work.
        All UI updates go through ``self._page.update()``.
        """
        if self._credential is None:
            self._set_status_error(
                "Credential not found in configuration."
            )
            return

        # ── Step 1: Login ───────────────────────────────────────────────
        self._set_downloading(True, "Connecting to R365…")
        self._log_handler.add_app_message(
            "Starting login…", level="info"
        )

        try:
            auth_result = R365Authenticator(
                self._tenant, self._credential
            ).login()
        except AuthError as exc:
            logger.error(
                "Login failed — %s: %s", type(exc).__name__, exc
            )
            self._log_handler.add_app_message(
                f"Login failed: {exc}", level="error"
            )
            self._set_status_error(
                f"Login failed: {type(exc).__name__} — {exc}"
            )
            return

        self._log_handler.add_app_message(
            "Login successful.", level="success"
        )
        self._set_downloading(True, "Fetching report parameters…")

        # ── Step 2: Download report ─────────────────────────────────────
        self._log_handler.add_app_message(
            f"Downloading GL Detailed Report  "
            f"{self._start_date}  →  {self._end_date}",
            level="info",
        )
        self._set_downloading(
            True, "Downloading report — may take 1–2 minutes…"
        )

        try:
            exporter = GLAccountDetailExporter(
                session=auth_result.session,
                tenant_host=auth_result.tenant_host,
                user_id=auth_result.user_id,
            )
            result = exporter.download(
                ReportRequest(
                    start_date=self._start_date,
                    end_date=self._end_date,
                    output_path=self._save_path,
                )
            )
        except ReportError as exc:
            logger.error(
                "Report failed — %s: %s", type(exc).__name__, exc
            )
            self._log_handler.add_app_message(
                f"Report download failed: {exc}", level="error"
            )
            self._set_status_error(
                f"Report failed: {type(exc).__name__} — {exc}"
            )
            return

        # ── Success ─────────────────────────────────────────────────────
        size_kb = result.file_size_bytes / 1024
        self._log_handler.add_app_message(
            f"Report saved:  {result.saved_path}  "
            f"({size_kb:.1f} KB)",
            level="success",
        )
        self._set_status_success(
            f"Report downloaded successfully — {size_kb:.1f} KB"
        )