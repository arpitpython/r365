"""
R365 credential management.

Wraps the project-agnostic ``utils.keychain.KeychainManager`` with the
R365-specific service name.  Passwords live in the OS keychain — never
in config files or source code.

Usage — first-time setup (run once per machine):
    python -m app.credentials setup

Usage — in code:
    from app.credentials import CredentialManager
    password = CredentialManager.get_password("AnalytixFFG")
"""

from __future__ import annotations

import getpass
import logging
import sys

from utils.keychain import KeychainManager, KeyringUnavailableError, PasswordNotFoundError

# Re-export so existing callers can catch these from app.credentials
__all__ = ["CredentialManager", "KeyringUnavailableError", "PasswordNotFoundError"]

logger = logging.getLogger(__name__)

# Service name in the OS keychain — keep stable across versions.
# Changing this will cause all users to lose their stored passwords.
_SERVICE_NAME = "R365DesktopTool"

_manager = KeychainManager(_SERVICE_NAME)


class CredentialManager:
    """
    R365 keychain facade — static-method API for backward compatibility.

    All calls delegate to the module-level KeychainManager(_SERVICE_NAME).
    New code may use the manager directly:
        from app.credentials import _manager
    """

    @staticmethod
    def save_password(username: str, password: str) -> None:
        _manager.save_password(username, password)

    @staticmethod
    def get_password(username: str) -> str:
        return _manager.get_password(username)

    @staticmethod
    def delete_password(username: str) -> None:
        _manager.delete_password(username)

    @staticmethod
    def has_password(username: str) -> bool:
        return _manager.has_password(username)


# ─────────────────────────────────────────────────────────────────────────────
#  CLI setup helper — run with:  python -m app.credentials setup
# ─────────────────────────────────────────────────────────────────────────────

def _cli_setup() -> None:
    """Interactive wizard to store R365 credentials in the OS keychain."""
    print("\n=== R365 Desktop Tool — Credential Setup ===\n")

    from app.config import TENANTS

    all_usernames: list[tuple[str, str]] = []  # (tenant_name, username)
    for tenant in TENANTS.values():
        for username in tenant.credentials:
            all_usernames.append((tenant.name, username))

    if not all_usernames:
        print("No credentials configured in config.py.")
        sys.exit(1)

    print("Configured accounts:")
    for i, (tenant_name, username) in enumerate(all_usernames, 1):
        stored = " [password stored]" if CredentialManager.has_password(username) else ""
        print(f"  {i}. {username}  ({tenant_name}){stored}")

    print()
    choice = input("Enter account number (or press Enter for all): ").strip()

    if choice == "":
        selected = all_usernames
    else:
        try:
            idx = int(choice) - 1
            selected = [all_usernames[idx]]
        except (ValueError, IndexError):
            print("Invalid choice.")
            sys.exit(1)

    for tenant_name, username in selected:
        print(f"\nSetting password for: {username}  ({tenant_name})")
        password = getpass.getpass("  Password: ")
        if not password:
            print("  Skipped (empty password).")
            continue
        confirm = getpass.getpass("  Confirm:  ")
        if password != confirm:
            print("  ERROR: Passwords do not match. Skipped.")
            continue
        CredentialManager.save_password(username, password)
        print(f"  Password stored in OS keychain.")

    print("\nSetup complete.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        _cli_setup()
    else:
        print("Usage: python -m app.credentials setup")
