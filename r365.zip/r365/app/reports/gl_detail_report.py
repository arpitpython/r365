"""
GL Account Detail Export — RunAndExport report.

Downloads the "GL Account Detail Export" SSRS report from R365 as an Excel file.

Flow (matching browser behaviour exactly):
    1. GET  /ServiceStack/ReportsPage         (via _reports_page helper)
       → Retrieves live report metadata (parameter IDs, labels, ValidValues).

    2. POST /ServiceStack/ValidateReport      (via _validate_report helper)
       → Server resolves hidden params: Database, SQLServer, TimeZoneCode,
         UtcOffset, and the full Account selectedItem list.
         Also warms up the SSRS session (required before RunAndExport).

    3. POST /NetCore/SsrsReport/RunAndExport
       → Returns {"url": "https://...blob.core.windows.net/...", "result": 1}

    4. GET  {url}  (Azure Blob SAS — no auth required)
       → Streams the .xlsx file to disk.
"""

from __future__ import annotations

import copy
import json as _json
import logging
from datetime import date
from pathlib import Path
from urllib.parse import quote

import requests

from ..exceptions import ReportExportFailed, ReportDownloadFailed
from ._reports_page import fetch_reports_page, ReportsPageResult
from ._validate_report import call_validate_report, ResolvedReportParams
from ..types import ReportRequest, ReportResult

logger = logging.getLogger(__name__)

# ── Report identity constants ──────────────────────────────────────────────
REPORT_NAME = "GL Account Detail Export"
REPORT_PATH = "/NA01/GL Account Detail Export"

EXPORT_FILE_TYPE = 1  # 1 = Excel (XLSX)

# Print settings — exactly as captured from browser
PRINT_SETTINGS = {
    "paperSizeType": 0,
    "isLandscape": True,
    "pageScalingType": 0,
    "percentOfNormalSize": 100,
    "numberOfPagesInWidth": 1,
    "numberOfPagesInHeight": 1,
    "topMargin": 0.43,
    "leftMargin": 0.33,
    "rightMargin": 0.33,
    "bottomMargin": 0.43,
    "footerMargin": 0.3,
    "isCenteredHorizontally": True,
    "isCenteredVertically": False,
    "pageOrderType": 0,
}


def _build_report_payload(
    resolved: ResolvedReportParams,
    reports_page: ReportsPageResult,
    start_date: date,
    end_date: date,
) -> dict:
    """
    Build the RunAndExport payload from live server-resolved parameter values.

    We start from the raw parameter list returned by ValidateReport (which
    already has selectedItem filled in for Database, SQLServer, TimeZoneCode,
    UtcOffset, and Account), then override only the two date parameters.
    """
    start_str = start_date.strftime("%m/%d/%Y")
    end_str   = end_date.strftime("%m/%d/%Y")

    # Deep-copy so we do not mutate the cached resolved params
    parameters = copy.deepcopy(resolved.raw_parameters)

    for param in parameters:
        label = param.get("label", "")

        if label == "Start":
            param["selectedItem"] = [{"display": None, "value": start_str, "wanted": False}]
            param["current"]  = False
            param["previous"] = False

        elif label == "End":
            param["selectedItem"] = [{"display": None, "value": end_str, "wanted": False}]
            param["current"]  = True
            param["previous"] = False

        elif label == "Account":
            if resolved.account_selected_items:
                param["selectedItem"] = copy.deepcopy(resolved.account_selected_items)
                param["selectAll"] = True

        # SortOrder is required by RunAndExport but absent from ReportsPage
        if "SortOrder" not in param:
            try:
                param["SortOrder"] = int(param.get("order", 0))
            except (TypeError, ValueError):
                param["SortOrder"] = 0

    return {
        "report": {
            "Id":         reports_page.report_id,
            "ReportName": reports_page.report_name,
            "ReportPath": reports_page.report_path,
            "Render":     reports_page.render,
            "Category":   reports_page.category,
            "ModifiedOn": reports_page.modified_on,
            "Parameter":  parameters,
        },
        "exportFileType":      EXPORT_FILE_TYPE,
        "reportPrintSettings": PRINT_SETTINGS,
    }


class GLAccountDetailExporter:
    """
    Downloads the GL Account Detail Export report from R365 as an Excel file.

    The two-step pre-flight (ReportsPage then ValidateReport) runs automatically
    on the first call to download(), ensuring Database, SQLServer, TimeZoneCode,
    UtcOffset, and the full account list are always current.

    Usage:
        exporter = GLAccountDetailExporter(
            session=auth_result.session,
            tenant_host=auth_result.tenant_host,
            user_id=auth_result.user_id,
        )
        result = exporter.download(ReportRequest(
            start_date=date(2025, 1, 1),
            end_date=date(2026, 3, 24),
            output_path="./downloads/gl_export.xlsx",
        ))
    """

    EXPORT_ENDPOINT = "/NetCore/SsrsReport/RunAndExport"

    def __init__(
        self,
        session: requests.Session,
        tenant_host: str,
        user_id: str,
        timeout: int = 600,  # 10 min — large reports can take 7-10 min
    ) -> None:
        self.session     = session
        self.tenant_host = tenant_host
        self.user_id     = user_id
        self.timeout     = timeout
        self.base_url    = f"https://{tenant_host}"

        # Populated by _preflight(); cached for the lifetime of this instance
        self._reports_page: ReportsPageResult | None = None
        self._resolved:     ResolvedReportParams | None = None

    # ── Public API ─────────────────────────────────────────────────────────

    def download(self, request: ReportRequest) -> ReportResult:
        """Run the pre-flight, trigger the export, and save the file."""
        self._preflight()
        logger.info(
            "Requesting %s: %s to %s",
            REPORT_NAME,
            request.start_date.strftime("%m/%d/%Y"),
            request.end_date.strftime("%m/%d/%Y"),
        )
        sas_url    = self._trigger_export(request.start_date, request.end_date)
        saved_path, size = self._download_file(sas_url, request.output_path)
        return ReportResult(
            report_name=REPORT_NAME,
            start_date=request.start_date,
            end_date=request.end_date,
            saved_path=saved_path,
            file_size_bytes=size,
        )

    # ── Pre-flight ─────────────────────────────────────────────────────────

    def _preflight(self) -> None:
        """
        Execute the two-step pre-flight:
            Step 1: ReportsPage    — get live report metadata
            Step 2: ValidateReport — resolve hidden params + warm up SSRS session

        Results are cached; calling download() multiple times on the same
        instance reuses the cached params safely within one session.
        """
        if self._reports_page is not None and self._resolved is not None:
            logger.debug("Pre-flight already complete; using cached params.")
            return

        logger.info("=== Pre-flight Step 1/2: ReportsPage ===")
        self._reports_page = fetch_reports_page(
            session=self.session,
            tenant_host=self.tenant_host,
            user_id=self.user_id,
            timeout=self.timeout,
        )

        logger.info("=== Pre-flight Step 2/2: ValidateReport ===")
        self._resolved = call_validate_report(
            session=self.session,
            tenant_host=self.tenant_host,
            user_id=self.user_id,
            reports_page_result=self._reports_page,
            timeout=self.timeout,
        )

        logger.info("Pre-flight complete: %s", self._resolved)

    # ── Export ─────────────────────────────────────────────────────────────

    def _trigger_export(self, start_date: date, end_date: date) -> str:
        """POST to RunAndExport. Returns the Azure Blob SAS URL."""
        assert self._reports_page is not None
        assert self._resolved is not None

        url     = f"{self.base_url}{self.EXPORT_ENDPOINT}"
        payload = _build_report_payload(
            resolved=self._resolved,
            reports_page=self._reports_page,
            start_date=start_date,
            end_date=end_date,
        )

        encoded_name = quote(REPORT_NAME, safe="")
        encoded_path = quote(REPORT_PATH, safe="")
        referer = (
            f"{self.base_url}/react/print-ssrs-report/export"
            f"/{encoded_name}/{encoded_path}/Brock%27s%20GL%20View/quick"
        )

        logger.info(
            "POST %s  Database=%s  SQLServer=%s  TZ=%s  Offset=%s  %s to %s",
            url,
            self._resolved.database,
            self._resolved.sql_server,
            self._resolved.tz_code,
            self._resolved.utc_offset,
            start_date.strftime("%m/%d/%Y"),
            end_date.strftime("%m/%d/%Y"),
        )
        logger.info("(This may take upto 5 minutes for large date ranges)")

        resp = self.session.post(
            url,
            json=payload,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": self.base_url,
                "Referer": referer,
                "X-R365-Client-App": "react",
                "DNT": "1",
            },
            timeout=self.timeout,
        )

        if resp.status_code == 401:
            raise ReportExportFailed(f"401 Unauthorized: {resp.text[:300]}")
        if resp.status_code == 403:
            raise ReportExportFailed(f"403 Forbidden: {resp.text[:300]}")
        if resp.status_code != 200:
            raise ReportExportFailed(
                f"RunAndExport returned {resp.status_code}: {resp.text[:500]}"
            )

        try:
            data = resp.json()
        except ValueError as exc:
            raise ReportExportFailed(
                f"Non-JSON response from RunAndExport: {resp.text[:500]}"
            ) from exc

        logger.info("RunAndExport response: %s", str(data)[:300])

        error  = data.get("error")
        result = data.get("result")

        if result == -1 and error:
            error_msg = error.get("message", "") if isinstance(error, dict) else str(error)
            error_id  = error.get("errorId",  "") if isinstance(error, dict) else ""
            params    = error.get("parameters") if isinstance(error, dict) else None
            logger.error(
                "SSRS error (errorId=%s): %s  parameters=%s",
                error_id, error_msg, params,
            )
            logger.error("Payload sent (truncated): %s", _json.dumps(payload)[:1000])
            raise ReportExportFailed(f"SSRS error (errorId={error_id}): {error_msg}")

        if result != 1:
            raise ReportExportFailed(
                f"result={result} (expected 1). Full response: {data}"
            )

        sas_url = data.get("url", "").strip()
        if not sas_url:
            raise ReportExportFailed(f"No url in RunAndExport response: {data}")

        logger.info("Export complete. Downloading from Azure Blob Storage")
        return sas_url

    # ── Download ───────────────────────────────────────────────────────────

    def _download_file(self, sas_url: str, output_path: str) -> tuple:
        """Stream the Excel file from the Azure SAS URL to disk."""
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.suffix.lower() != ".xlsx":
            output = output.with_suffix(".xlsx")

        dl = requests.Session()
        dl.headers.update({"Accept": "*/*"})

        try:
            resp = dl.get(sas_url, stream=True, timeout=self.timeout)
        except requests.RequestException as exc:
            raise ReportDownloadFailed(f"Could not reach download URL: {exc}") from exc

        if resp.status_code != 200:
            raise ReportDownloadFailed(f"Azure Blob returned {resp.status_code}.")

        bytes_written = 0
        with open(output, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65_536):
                if chunk:
                    f.write(chunk)
                    bytes_written += len(chunk)

        logger.info("Saved: %s  (%.1f KB)", output, bytes_written / 1024)
        return str(output), bytes_written
