"""
Helper — ReportsPage fetcher.

Retrieves the live report catalogue from R365 after login.
The browser calls GET /ServiceStack/ReportsPage to load the full list of
reports with their parameter definitions.  We use this to:

  1. Locate the GL Account Detail Export entry by ReportName.
  2. Extract the live Parameter array (IDs, labels, ValidValues, control
     types, default values) so that subsequent calls never rely on
     hardcoded parameter UUIDs or metadata.

Single responsibility: one HTTP call, one parsed result.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import requests

from ..exceptions import UpstreamChangedError

logger = logging.getLogger(__name__)

# The report we care about — matched case-insensitively against ReportName.
_GL_REPORT_NAME = "GL Account Detail Export"


class ReportsPageResult:
    """Parsed outcome of a ReportsPage call for a single report."""

    def __init__(self, raw_report: Dict[str, Any]) -> None:
        self._raw = raw_report

    # ── Accessors ──────────────────────────────────────────────────────────

    @property
    def report_id(self) -> str:
        return self._raw["Id"]

    @property
    def report_name(self) -> str:
        return self._raw["ReportName"]

    @property
    def report_path(self) -> str:
        return self._raw["ReportPath"]

    @property
    def render(self) -> str:
        return self._raw.get("Render", "HTML5")

    @property
    def category(self) -> str:
        return self._raw.get("Category", "")

    @property
    def modified_on(self) -> str:
        return self._raw.get("ModifiedOn", "")

    @property
    def parameters(self) -> List[Dict[str, Any]]:
        """Raw Parameter array as returned by the server."""
        params = self._raw.get("Parameter", [])
        # Normalise: server may return a single dict instead of a list
        if isinstance(params, dict):
            return [params]
        return params or []

    @property
    def iframe_path(self) -> str:
        """SSRS report-server base URL embedded in the response."""
        return self._raw.get(
            "iframePath",
            "https://na01reports.restaurant365.com/ReportServer/Pages/ReportViewer.aspx?/NA01",
        )

    def get_parameter(self, label: str) -> Optional[Dict[str, Any]]:
        """Return the parameter dict whose label matches *label* (case-insensitive)."""
        label_lower = label.lower()
        for p in self.parameters:
            if p.get("label", "").lower() == label_lower:
                return p
        return None

    def get_parameter_id(self, label: str) -> Optional[str]:
        """Convenience: return the UUID for a parameter by label."""
        p = self.get_parameter(label)
        return p.get("id") if p else None

    def as_raw(self) -> Dict[str, Any]:
        """Return the original dict for use as the 'rep' key in ValidateReport."""
        return self._raw


def fetch_reports_page(
    session: requests.Session,
    tenant_host: str,
    user_id: str,
    timeout: int = 30,
) -> ReportsPageResult:
    """
    Call GET /ServiceStack/ReportsPage and return the GL Account Detail
    Export entry as a ReportsPageResult.

    Args:
        session:      Authenticated requests.Session from R365Authenticator.
        tenant_host:  e.g. "fortisfranchise.restaurant365.com"
        user_id:      Permanent UUID for the logged-in user.
        timeout:      Request timeout in seconds.

    Returns:
        ReportsPageResult wrapping the GL Account Detail Export entry.

    Raises:
        UpstreamChangedError — if the endpoint fails or the GL report is
                               not found in the response.
    """
    base = f"https://{tenant_host}"
    url  = f"{base}/ServiceStack/ReportsPage"

    logger.info("Fetching ReportsPage from: %s", url)

    resp = session.get(
        url,
        headers={
            "Accept": "application/json",
            "Referer": f"{base}/react/reports-management/legacy/MyReports",
            "reportpath": (
                "https://na01reports.restaurant365.com"
                "/ReportServer/Pages/ReportViewer.aspx?/NA01"
            ),
            "userid": user_id,
            "X-R365-Client-App": "react",
            "DNT": "1",
        },
        timeout=timeout,
    )

    if resp.status_code != 200:
        raise UpstreamChangedError(
            f"ReportsPage returned {resp.status_code}: {resp.text[:300]}"
        )

    try:
        data = resp.json()
    except ValueError as exc:
        raise UpstreamChangedError(
            f"ReportsPage returned non-JSON: {resp.text[:300]}"
        ) from exc

    # Navigate the response envelope: {"Reports": {"Report": [...]}}
    report_list: List[Dict[str, Any]] = []
    reports_obj = data.get("Reports") or data
    if isinstance(reports_obj, dict):
        inner = reports_obj.get("Report") or reports_obj.get("reports") or []
        if isinstance(inner, list):
            report_list = inner
        elif isinstance(inner, dict):
            report_list = [inner]
    elif isinstance(reports_obj, list):
        report_list = reports_obj

    if not report_list:
        raise UpstreamChangedError(
            "ReportsPage response contained no reports. "
            f"Top-level keys: {list(data.keys())}"
        )

    # Find the GL Account Detail Export entry
    gl_report: Optional[Dict[str, Any]] = None
    for entry in report_list:
        if entry.get("ReportName", "").lower() == _GL_REPORT_NAME.lower():
            gl_report = entry
            break

    if gl_report is None:
        names = [r.get("ReportName", "?") for r in report_list[:10]]
        raise UpstreamChangedError(
            f"'{_GL_REPORT_NAME}' not found in ReportsPage response. "
            f"First 10 report names: {names}"
        )

    logger.info(
        "ReportsPage: found '%s' (id=%s, params=%d)",
        gl_report.get("ReportName"),
        gl_report.get("Id"),
        len(gl_report.get("Parameter", []) or []),
    )

    return ReportsPageResult(gl_report)
