"""
R365 reports package.

Each module is one downloadable report:
    gl_detail_report.py   — GL Account Detail Export  (RunAndExport)

Internal helpers (underscore prefix = not a report, do not import directly):
    _reports_page.py      — fetches live report catalogue from /ServiceStack/ReportsPage
    _validate_report.py   — resolves server-side hidden params via /ServiceStack/ValidateReport
"""

from .gl_detail_report import GLAccountDetailExporter

__all__ = ["GLAccountDetailExporter"]
