"""
Helper — ValidateReport caller.

Resolves server-side hidden parameters for the GL Account Detail Export report.
The browser calls POST /ServiceStack/ValidateReport immediately after ReportsPage
to let the server fill in the hidden, tenant-specific params:

    Database      → tenant DB name  (e.g. "fortisfranchise")
    SQLServer     → SSRS SQL host   (e.g. "pro-sqlag-631.restaurant365.com")
    TimeZoneCode  → TZ abbreviation (e.g. "EDT")
    UtcOffset     → UTC offset str  (e.g. "-04")

It also resolves the full Account selectedItem list — the complete chart of
accounts for this tenant, read live from the ValidateReport response.

Single responsibility: one HTTP call, one parsed result.
"""

from __future__ import annotations

import copy
import logging
from datetime import date
from typing import Any, Dict, List, Optional

import requests

from ..exceptions import UpstreamChangedError
from ._reports_page import ReportsPageResult

logger = logging.getLogger(__name__)

# Labels for the four hidden params we need to extract
_HIDDEN_LABELS = {"Database", "SQLServer", "TimeZoneCode", "UtcOffset"}

# Sentinel value used in the ValidateReport request for date fields
_TODAY_STR = date.today().strftime("%m/%d/%Y")


class ResolvedReportParams:
    """
    All parameter values resolved by ValidateReport that are required
    to build a correct RunAndExport payload.
    """

    def __init__(
        self,
        database: str,
        sql_server: str,
        tz_code: str,
        utc_offset: str,
        account_selected_items: List[Dict[str, Any]],
        raw_parameters: List[Dict[str, Any]],
    ) -> None:
        self.database               = database
        self.sql_server             = sql_server
        self.tz_code                = tz_code
        self.utc_offset             = utc_offset
        self.account_selected_items = account_selected_items
        # Full resolved parameter list — used verbatim in RunAndExport
        self.raw_parameters         = raw_parameters

    def __repr__(self) -> str:
        return (
            f"ResolvedReportParams("
            f"database={self.database!r}, "
            f"sql_server={self.sql_server!r}, "
            f"tz_code={self.tz_code!r}, "
            f"utc_offset={self.utc_offset!r}, "
            f"accounts={len(self.account_selected_items)})"
        )


def _extract_selected_value(param: Dict[str, Any]) -> Optional[str]:
    """
    Pull the first selectedItem value from a resolved parameter dict.
    The server may return selectedItem as a list of dicts or as a single dict.
    """
    selected = param.get("selectedItem")
    if not selected:
        return None
    if isinstance(selected, list) and selected:
        return selected[0].get("value") or selected[0].get("display")
    if isinstance(selected, dict):
        return selected.get("value") or selected.get("display")
    return None


def _build_validate_payload(
    user_id: str,
    reports_page_result: ReportsPageResult,
) -> Dict[str, Any]:
    """
    Construct the POST body for /ServiceStack/ValidateReport.

    We use the raw report dict from ReportsPage as the 'rep' value and
    inject the default selectedItem values for each visible parameter
    (matching exactly what the browser sends).

    Hidden params (Database, SQLServer, TimeZoneCode, UtcOffset) are sent
    with empty selectedItem so the server resolves them for this tenant/user.
    """
    rep = copy.deepcopy(reports_page_result.as_raw())

    for param in rep.get("Parameter", []) or []:
        label   = param.get("label", "")
        visible = str(param.get("visible", "0")) == "1"

        if label in _HIDDEN_LABELS:
            param.setdefault("selectedItem", [])
            param.setdefault("controlType", "Input")
            param.setdefault("quickAsOf", False)
            param.setdefault("labelArray", [label])
            param.setdefault("isMulti", False)
            param.setdefault("width", "300px")
            param.setdefault("showMe", False)
            param.setdefault("searchText", "")
            continue

        if label == "AccountsAvailable":
            param["selectedItem"] = [
                {"value": "22222222-2222-2222-2222-222222222222",
                 "display": "All Profit & Loss Accounts"}
            ]
            param.setdefault("hideSelectAll", "true")
            param.setdefault("controlType", "DynamicDropDown")
            param.setdefault("isMulti", True)
            param.setdefault("noCache", True)
            param.setdefault("selectAll", False)
            param.setdefault("searchText", [
                {"value": "22222222-2222-2222-2222-222222222222",
                 "display": "All Profit & Loss Accounts"}
            ])

        elif label == "Account":
            param["selectedItem"] = []
            param["selectAll"] = True
            param.setdefault("controlType", "DynamicDropDown")
            param.setdefault("isMulti", True)
            param.setdefault("noCache", True)
            param.setdefault("searchText", [{}])

        elif label == "DaysBack":
            param["selectedItem"] = [{"value": "1"}]
            param.setdefault("controlType", "Input")
            param.setdefault("isMulti", False)
            param.setdefault("showMe", False)

        elif label == "Start":
            param["selectedItem"] = [{"value": _TODAY_STR}]
            param.setdefault("controlType", "DatePicker")
            param.setdefault("isMulti", False)

        elif label == "End":
            param["selectedItem"] = [{"value": _TODAY_STR}]
            param["current"] = True
            param.setdefault("controlType", "DatePicker")
            param.setdefault("isMulti", False)

        elif label == "FilterBy":
            param["selectedItem"] = [{"value": "Show All", "display": "Show All"}]
            param.setdefault("controlType", "DynamicDropDown")
            param.setdefault("isMulti", False)
            param.setdefault("noCache", True)
            param.setdefault("searchText", [{"value": "Show All", "display": "Show All"}])
            param.setdefault("selectAll", False)

        elif label == "Filter":
            param["selectedItem"] = [
                {"value": "00000000-0000-0000-0000-000000000000",
                 "display": "All Locations"}
            ]
            param.setdefault("controlType", "DynamicDropDown")
            param.setdefault("isMulti", True)
            param.setdefault("noCache", True)
            param.setdefault("searchText", [
                {"value": "00000000-0000-0000-0000-000000000000",
                 "display": "All Locations"}
            ])
            param.setdefault("selectAll", False)

        elif label == "Parent":
            param["selectedItem"] = [{"value": "1", "display": "Include Subaccounts"}]

        elif label == "ShowUnapproved":
            param["selectedItem"] = [{"value": "1", "display": "Yes"}]

        elif label == "Calendar":
            param["selectedItem"] = [{"value": "1", "display": "Fiscal"}]

        elif label == "SumByTrx":
            param["selectedItem"] = [{"value": "0", "display": "No"}]

        elif label == "IncludeStatAccounts":
            param["selectedItem"] = [{"value": "0", "display": "No"}]

        elif label == "HideZeroBalances":
            param["selectedItem"] = [{"value": "TRUE", "display": "Yes"}]

        elif label == "ExcludeAccountsWithoutActivity":
            param["selectedItem"] = [{"value": "False", "display": "No"}]

        elif label == "IncludeRefLinks":
            param["selectedItem"] = [{"value": "1", "display": "Yes"}]

    rep.setdefault("iframePath", reports_page_result.iframe_path)
    rep.setdefault("tooltip", "Quick Parameters")
    rep.setdefault("selectedDirection", "right")
    rep.setdefault("quickAddDisabled", False)

    return {"userId": user_id, "rep": rep}


def call_validate_report(
    session: requests.Session,
    tenant_host: str,
    user_id: str,
    reports_page_result: ReportsPageResult,
    timeout: int = 60,
) -> ResolvedReportParams:
    """
    POST /ServiceStack/ValidateReport and extract the resolved parameter
    values needed for RunAndExport.

    Args:
        session:             Authenticated requests.Session.
        tenant_host:         e.g. "fortisfranchise.restaurant365.com"
        user_id:             Permanent UUID for the logged-in user.
        reports_page_result: Result from fetch_reports_page().
        timeout:             Request timeout in seconds.

    Returns:
        ResolvedReportParams with live Database, SQLServer, TimeZoneCode,
        UtcOffset, and full Account selectedItem list.

    Raises:
        UpstreamChangedError — if the call fails or required params are absent.
    """
    base    = f"https://{tenant_host}"
    url     = f"{base}/ServiceStack/ValidateReport"
    payload = _build_validate_payload(user_id, reports_page_result)

    logger.info("Calling ValidateReport at: %s", url)

    resp = session.post(
        url,
        json=payload,
        headers={
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json; charset=UTF-8",
            "Origin": base,
            "Referer": f"{base}/",
            "X-R365-Client-App": "angular",
            "userid": user_id,
            "DNT": "1",
        },
        timeout=timeout,
    )

    if resp.status_code != 200:
        raise UpstreamChangedError(
            f"ValidateReport returned {resp.status_code}: {resp.text[:300]}"
        )

    try:
        data = resp.json()
    except ValueError as exc:
        raise UpstreamChangedError(
            f"ValidateReport returned non-JSON: {resp.text[:300]}"
        ) from exc

    logger.info(
        "ValidateReport response preview: %s",
        str(data)[:300].replace("\n", " "),
    )

    rep_resp: Dict[str, Any] = data if isinstance(data, dict) else {}

    if "Parameter" not in rep_resp and "rep" in rep_resp:
        rep_resp = rep_resp["rep"]

    raw_parameters: List[Dict[str, Any]] = rep_resp.get("Parameter") or []
    if isinstance(raw_parameters, dict):
        raw_parameters = [raw_parameters]

    # ── Extract the four hidden server-resolved values ────────────────────
    resolved: Dict[str, str] = {}
    account_items: List[Dict[str, Any]] = []

    for param in raw_parameters:
        label = param.get("label", "")

        if label in _HIDDEN_LABELS:
            value = _extract_selected_value(param)
            if value:
                resolved[label] = value
                logger.info("ValidateReport resolved %s = %s", label, value)

        elif label == "Account":
            selected = param.get("selectedItem")
            if isinstance(selected, list) and selected:
                account_items = [
                    item for item in selected
                    if isinstance(item, dict) and item.get("value")
                ]
                logger.info(
                    "ValidateReport resolved Account list: %d items",
                    len(account_items),
                )

    # ── Validate all four hidden params were resolved ─────────────────────
    missing = _HIDDEN_LABELS - set(resolved.keys())
    if missing:
        received_labels = [p.get("label") for p in raw_parameters]
        logger.warning(
            "ValidateReport did not resolve: %s. "
            "Received parameter labels: %s",
            missing, received_labels,
        )
        if len(missing) == len(_HIDDEN_LABELS):
            raise UpstreamChangedError(
                f"ValidateReport response missing all hidden params. "
                f"Parameter labels received: {received_labels}"
            )
        raise UpstreamChangedError(
            f"ValidateReport response missing required params: {missing}. "
            f"Got: {list(resolved.keys())}"
        )

    if not account_items:
        logger.warning(
            "ValidateReport returned no Account selectedItems. "
            "RunAndExport will use selectAll=True without an explicit list."
        )

    return ResolvedReportParams(
        database               = resolved["Database"],
        sql_server             = resolved["SQLServer"],
        tz_code                = resolved["TimeZoneCode"],
        utc_offset             = resolved["UtcOffset"],
        account_selected_items = account_items,
        raw_parameters         = raw_parameters,
    )
