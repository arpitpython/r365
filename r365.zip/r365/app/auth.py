"""
R365 authentication flow via IdentityServer (form login + OIDC form_post).
"""

from __future__ import annotations

import logging
from typing import Optional
from urllib.parse import unquote

import requests

from .config import (
    SETTINGS, Tenant, Credential,
    CLIENT_ID, SCOPES, RESPONSE_TYPE, RESPONSE_MODE, CODE_CHALLENGE_METHOD,
    build_acr_values,
)
from .exceptions import (
    AntiForgeryTokenNotFound,
    InvalidCredentialsError,
    MfaRequiredError,
    OidcCallbackError,
    SessionVerificationError,
    UpstreamChangedError,
)
from .types import AuthResult, LoginPage, LoginFormInfo, OidcFormPost
from .utils import (
    create_session_with_retries,
    extract_hidden_input,
    extract_oidc_form_post,
    is_identity_login_url,
    is_oidc_callback_url,
    find_identity_login_url,
    contains_mfa_indicators,
    build_identity_login_url,
    generate_code_verifier,
    generate_code_challenge,
    generate_state,
    generate_nonce,
    get_tenant_slug_from_host,
    parse_login_form,
)

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


class R365Authenticator:

    def __init__(
        self,
        tenant: Tenant,
        credential: Credential,
        user_agent: Optional[str] = None,
    ) -> None:
        self.tenant     = tenant
        self.credential = credential
        self.user_agent = user_agent or SETTINGS.default_user_agent
        self.session    = create_session_with_retries(
            user_agent=self.user_agent,
            max_retries=SETTINGS.max_retries,
            backoff_factor=SETTINGS.backoff_factor,
            verify_tls=SETTINGS.verify_tls,
        )
        self.timeout = SETTINGS.request_timeout_seconds
        self._pkce_verifier: Optional[str] = None
        self._oidc_state: Optional[str] = None
        self._oidc_nonce: Optional[str] = None

    def login(self) -> AuthResult:
        # First OIDC cycle
        login_url  = self._begin_flow_and_capture_login_url()
        login_page = self._get_login_page(login_url)
        oidc_post1 = self._submit_credentials(login_page)
        resp1      = self._complete_oidc_callback(oidc_post1, cycle=1)

        # Second OIDC cycle
        self._complete_second_oidc_if_needed(resp1)

        # Session verification
        self._verify_session_authenticated()

        # Bootstrap cookies
        self._bootstrap_servicestack()
        self._inject_app_cookies()

        cookies = self.session.cookies.get_dict()
        logger.info("Login complete. userId=%s  Cookies: %s",
                    self.credential.user_id, list(cookies.keys()))

        return AuthResult(
            session=self.session,
            tenant_host=self.tenant.subdomain_host,
            final_url=resp1.url,
            cookies=cookies,
            user_id=self.credential.user_id,
        )

    def _begin_flow_and_capture_login_url(self) -> str:
        start_url = f"https://{self.tenant.subdomain_host}/react/home"
        logger.info("Starting auth flow at: %s", start_url)
        resp = self.session.get(start_url, allow_redirects=True, timeout=self.timeout)

        for hop in list(resp.history) + [resp]:
            if is_identity_login_url(hop.url):
                return hop.url
            loc = hop.headers.get("Location", "")
            if loc and is_identity_login_url(loc):
                return loc

        if resp.status_code == 200 and "text/html" in resp.headers.get("Content-Type", ""):
            found = find_identity_login_url(resp.text, SETTINGS.identity_host)
            if found:
                return found

        logger.info("Constructing Identity login URL (PKCE fallback).")
        tenant_slug    = get_tenant_slug_from_host(self.tenant.subdomain_host)
        code_verifier  = generate_code_verifier()
        code_challenge = generate_code_challenge(code_verifier)
        state = generate_state()
        nonce = generate_nonce()
        self._pkce_verifier = code_verifier
        self._oidc_state    = state
        self._oidc_nonce    = nonce

        return build_identity_login_url(
            tenant_host=self.tenant.subdomain_host,
            identity_host=SETTINGS.identity_host,
            client_id=CLIENT_ID, scopes=SCOPES,
            response_type=RESPONSE_TYPE, response_mode=RESPONSE_MODE,
            code_challenge=code_challenge, code_challenge_method=CODE_CHALLENGE_METHOD,
            state=state, nonce=nonce,
            acr_values=build_acr_values(tenant_slug),
        )

    def _get_login_page(self, login_url: str) -> LoginPage:
        logger.info("Fetching Identity login page.")
        resp = self.session.get(login_url, timeout=self.timeout)
        if resp.status_code != 200:
            raise UpstreamChangedError(f"Login page returned {resp.status_code}.")

        form_info = parse_login_form(resp.text, base_url=login_url)

        if "__RequestVerificationToken" not in form_info.hidden_fields:
            token = extract_hidden_input(resp.text, "__RequestVerificationToken")
            if not token:
                raise AntiForgeryTokenNotFound("Login page missing __RequestVerificationToken.")
            form_info = LoginFormInfo(
                action_url=form_info.action_url,
                hidden_fields={**form_info.hidden_fields, "__RequestVerificationToken": token},
                username_field=form_info.username_field,
                password_field=form_info.password_field,
                submit_field=form_info.submit_field,
                submit_value=form_info.submit_value,
            )
        logger.info("Login form parsed.")
        return LoginPage(login_url=login_url, form=form_info)

    def _submit_credentials(self, login_page: LoginPage) -> OidcFormPost:
        logger.info("Submitting credentials.")
        form = {
            **login_page.form.hidden_fields,
            login_page.form.username_field: self.credential.username,
            login_page.form.password_field: self.credential.get_password(),
        }
        if login_page.form.submit_field and login_page.form.submit_value:
            form[login_page.form.submit_field] = login_page.form.submit_value

        resp = self.session.post(
            login_page.form.action_url,
            data=form,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": f"https://{SETTINGS.identity_host}",
                "Referer": login_page.login_url,
            },
            allow_redirects=True,
            timeout=self.timeout,
        )

        if resp.status_code in (401, 403):
            raise InvalidCredentialsError("Credentials rejected (401/403).")

        oidc_post = extract_oidc_form_post(resp.text)
        if oidc_post:
            logger.info("OIDC form_post received (cycle 1).")
            return oidc_post

        if is_identity_login_url(resp.url):
            if contains_mfa_indicators(resp.text):
                raise MfaRequiredError("MFA challenge detected.")
            lower = resp.text.lower()
            if any(h in lower for h in ("invalid", "incorrect", "try again", "failed")):
                raise InvalidCredentialsError("Invalid credentials (error on page).")

        snippet = resp.text[:500].replace("\n", " ") if resp.text else ""
        raise UpstreamChangedError(
            f"No OIDC form_post found. URL={resp.url!r} "
            f"Status={resp.status_code} Snippet={snippet!r}"
        )

    def _complete_oidc_callback(self, oidc_post: OidcFormPost, cycle: int = 1) -> requests.Response:
        logger.info("Relaying OIDC form_post (cycle %d) to: %s", cycle, oidc_post.action_url)
        resp = self.session.post(
            oidc_post.action_url,
            data=oidc_post.fields,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": f"https://{SETTINGS.identity_host}",
                "Referer": f"https://{SETTINGS.identity_host}/",
            },
            allow_redirects=True,
            timeout=self.timeout,
        )

        for hop in list(resp.history) + [resp]:
            if is_identity_login_url(hop.url):
                raise OidcCallbackError(
                    f"OIDC callback (cycle {cycle}) redirected back to login. URL={resp.url!r}"
                )

        if resp.status_code not in (200, 302):
            raise OidcCallbackError(f"OIDC callback (cycle {cycle}) returned {resp.status_code}.")

        logger.info("OIDC callback cycle %d complete. Final URL=%s", cycle, resp.url[:120])
        return resp

    def _complete_second_oidc_if_needed(self, resp1: requests.Response) -> None:
        """
        Follow the second OIDC authorize cycle if present.
        Logs full details so we can debug exactly what happens.
        """
        final_url = resp1.url

        if not is_oidc_callback_url(final_url):
            logger.info("No second OIDC cycle (final URL is not /connect/authorize).")
            return

        logger.info("Second OIDC authorize detected. GET %s", final_url[:120])

        resp2 = self.session.get(final_url, allow_redirects=True, timeout=self.timeout)

        logger.info(
            "Second OIDC GET -> status=%d  final_url=%s",
            resp2.status_code, resp2.url[:120],
        )
        logger.info(
            "Second OIDC response body preview (first 400 chars): %s",
            resp2.text[:400].replace("\n", " "),
        )

        oidc_post2 = extract_oidc_form_post(resp2.text)
        if oidc_post2:
            logger.info(
                "Second OIDC form_post found. action=%s fields=%s",
                oidc_post2.action_url, list(oidc_post2.fields.keys()),
            )
            resp3 = self._complete_oidc_callback(oidc_post2, cycle=2)
            logger.info(
                "After cycle 2 callback: URL=%s  Cookies=%s",
                resp3.url[:120], list(self.session.cookies.keys()),
            )
            return

        # No form_post found — log what we got and keep going
        logger.warning(
            "Second OIDC: no form_post in response. "
            "status=%d  url=%s  body_preview=%s",
            resp2.status_code,
            resp2.url[:120],
            resp2.text[:600].replace("\n", " "),
        )

    def _verify_session_authenticated(self) -> None:
        probe_url = f"https://{self.tenant.subdomain_host}/react/home"
        logger.info("Verifying session at: %s", probe_url)
        resp = self.session.get(probe_url, allow_redirects=True, timeout=self.timeout)
        for hop in list(resp.history) + [resp]:
            if is_identity_login_url(hop.url):
                raise SessionVerificationError("Redirected back to login during verification.")
        if resp.status_code != 200:
            raise SessionVerificationError(f"Verification returned {resp.status_code}.")
        logger.info("Session verified successfully.")

    def _bootstrap_servicestack(self) -> None:
        """Call ServiceStack init endpoint to acquire ss-id and ss-pid."""
        base = f"https://{self.tenant.subdomain_host}"
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Referer": f"{base}/",
            "X-R365-Client-App": "angular",
            "DNT": "1",
        }
        try:
            resp = self.session.get(
                f"{base}/ServiceStack/RetrieveAllClientSetting",
                headers=headers, timeout=self.timeout,
            )
            logger.info(
                "ServiceStack bootstrap -> %d  Cookies: %s",
                resp.status_code, list(self.session.cookies.keys()),
            )
        except Exception as exc:
            logger.warning("ServiceStack bootstrap failed: %s", exc)

    def _inject_app_cookies(self) -> None:
        """Inject cookies that the React SPA sets via JS on first load."""
        domain = self.tenant.subdomain_host
        # Browser encodes spaces as + in userName cookie
        username_encoded = self.credential.display_name.replace(" ", "+")
        cookies_to_inject = {
            "userId":         self.credential.user_id,
            "userName":       username_encoded,
            "appPath":        self.tenant.app_path,
            "changePassword": "0",
            "defaultPage":    "",
        }
        for name, value in cookies_to_inject.items():
            self.session.cookies.set(name, value, domain=domain)
            logger.info("Injected cookie: %s=%s", name, value)