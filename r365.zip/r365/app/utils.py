"""
Utility functions: HTTP session, HTML parsing, URL detection, OIDC helpers.

Single responsibility:
- Reusable helpers with no business logic.
"""

from __future__ import annotations

import base64
import hashlib
import html as htmllib
import logging
import os
import re
from typing import Optional, Dict
from urllib.parse import urlencode, urlparse, quote, urljoin

from bs4 import BeautifulSoup  # type: ignore
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry  # type: ignore

from .types import LoginFormInfo, OidcFormPost

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
#  HTTP Session
# ─────────────────────────────────────────────

def create_session_with_retries(
    user_agent: str,
    max_retries: int = 3,
    backoff_factor: float = 0.5,
    status_forcelist: Optional[list] = None,
    allowed_methods: Optional[list] = None,
    verify_tls: bool = True,
) -> requests.Session:
    """
    Create a requests.Session with retry/backoff for idempotent requests.
    POST is intentionally excluded from retries to avoid duplicate submissions.
    """
    if status_forcelist is None:
        status_forcelist = [429, 500, 502, 503, 504]
    if allowed_methods is None:
        allowed_methods = ["HEAD", "GET", "OPTIONS"]

    session = requests.Session()
    retry = Retry(
        total=max_retries,
        read=max_retries,
        connect=max_retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=frozenset(allowed_methods),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    session.headers.update({
        "User-Agent": user_agent,
        "Accept": (
            "text/html,application/xhtml+xml,application/xml;q=0.9,"
            "image/avif,image/webp,image/apng,*/*;q=0.8,"
            "application/signed-exchange;v=b3;q=0.7"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "DNT": "1",
    })
    session.verify = verify_tls
    return session


# ─────────────────────────────────────────────
#  URL detection
# ─────────────────────────────────────────────

def is_identity_login_url(url: str) -> bool:
    """
    Return True if the URL is the IdentityServer login page.

    NOTE: /connect/authorize/callback is NOT a login URL — it is the valid
    OIDC endpoint that serves the form_post response after successful login.
    We deliberately do NOT match it here to avoid false positives.
    """
    parsed = urlparse(url)
    return "/Account/Login" in parsed.path


def is_oidc_callback_url(url: str) -> bool:
    """
    Return True if the URL is an OIDC authorize endpoint.
    Matches /connect/authorize and /connect/authorize/callback.
    The second OIDC cycle lands on /connect/authorize (no /callback).
    """
    parsed = urlparse(url)
    return "/connect/authorize" in parsed.path


# ─────────────────────────────────────────────
#  HTML helpers
# ─────────────────────────────────────────────

def extract_hidden_input(html: str, name: str) -> Optional[str]:
    """Extract the value of a hidden <input> field by name."""
    soup = BeautifulSoup(html, "html.parser")
    field = soup.find("input", {"name": name, "type": "hidden"})
    return field["value"] if field and field.has_attr("value") else None


def find_identity_login_url(html: str, identity_host: str) -> Optional[str]:
    """
    Attempt to discover the Identity login URL from an HTML page that performs
    a client-side redirect (anchor, meta refresh, or inline JS).
    """
    soup = BeautifulSoup(html, "html.parser")

    # a) Anchor tags
    for a in soup.find_all("a", href=True):
        href = htmllib.unescape(a["href"])
        if "/Account/Login" in href and "ReturnUrl=" in href:
            return href if href.startswith("http") else f"https://{identity_host}{href}"

    # b) Meta refresh
    meta = soup.find("meta", attrs={"http-equiv": re.compile(r"refresh", re.I)})
    if meta and meta.get("content"):
        m = re.search(r"url\s*=\s*['\"]?([^'\";]+)", meta["content"], flags=re.I)
        if m:
            href = htmllib.unescape(m.group(1).strip())
            if "/Account/Login" in href and "ReturnUrl=" in href:
                return href if href.startswith("http") else f"https://{identity_host}{href}"

    # c) JS redirect patterns
    patterns = [
        r'(?:window\.)?location\.href\s*=\s*["\'](?P<url>https?://[^"\']+/Account/Login\?ReturnUrl=[^"\']+)["\']',
        r'(?:window\.)?location\s*=\s*["\'](?P<url>https?://[^"\']+/Account/Login\?ReturnUrl=[^"\']+)["\']',
        r'location\.replace\(\s*["\'](?P<url>https?://[^"\']+/Account/Login\?ReturnUrl=[^"\']+)["\']\s*\)',
        r'["\'](?P<url>/Account/Login\?ReturnUrl=[^"\']+)["\']',
    ]
    for pat in patterns:
        m = re.search(pat, html, flags=re.I)
        if m:
            href = htmllib.unescape(m.group("url"))
            return href if href.startswith("http") else f"https://{identity_host}{href}"

    return None


def parse_login_form(html: str, base_url: str) -> LoginFormInfo:
    """
    Parse the login form from the Identity login page.

    Returns a LoginFormInfo with the action URL, all hidden fields,
    and the field names for username/password/submit.
    """
    soup = BeautifulSoup(html, "html.parser")

    # Find the form containing a password input
    form = None
    for f in soup.find_all("form"):
        if f.find("input", {"type": "password"}):
            form = f
            break
    if form is None:
        form = soup.find("form")
    if form is None:
        raise ValueError("No form found on login page.")

    action_url = urljoin(base_url, form.get("action") or "")

    hidden_fields: Dict[str, str] = {}
    for inp in form.find_all("input", {"type": "hidden"}):
        name = inp.get("name")
        if name:
            hidden_fields[name] = inp.get("value", "")

    # Resolve username field
    username_field: Optional[str] = None
    if form.find("input", {"name": "Username"}):
        username_field = "Username"
    if not username_field:
        cand = form.find("input", {"type": re.compile(r"^(text|email)$", re.I)})
        if cand and cand.get("name"):
            username_field = cand["name"]
    username_field = username_field or "Username"

    # Resolve password field
    password_field: Optional[str] = None
    if form.find("input", {"name": "Password"}):
        password_field = "Password"
    if not password_field:
        cand = form.find("input", {"type": "password"})
        if cand and cand.get("name"):
            password_field = cand["name"]
    password_field = password_field or "Password"

    # Resolve submit button (optional)
    submit_name: Optional[str] = None
    submit_value: Optional[str] = None
    submit = form.find("button", {"type": "submit"})
    if submit and submit.get("name"):
        submit_name = submit["name"]
        submit_value = submit.get("value") or submit.get_text(strip=True) or "login"
    else:
        inp_submit = form.find("input", {"type": "submit"})
        if inp_submit and inp_submit.get("name"):
            submit_name = inp_submit["name"]
            submit_value = inp_submit.get("value", "login")
        elif form.find("input", {"name": "button"}):
            submit_name = "button"
            submit_value = "login"

    return LoginFormInfo(
        action_url=action_url,
        hidden_fields=hidden_fields,
        username_field=username_field,
        password_field=password_field,
        submit_field=submit_name,
        submit_value=submit_value,
    )


def extract_oidc_form_post(html: str) -> Optional[OidcFormPost]:
    """
    Detect and parse the OIDC form_post page that IdentityServer returns
    after successful credential acceptance.

    The page contains a self-submitting form like:
        <form method='post' action='https://tenant.../NetCore/signin-oidc'>
          <input type='hidden' name='code'  value='...' />
          <input type='hidden' name='state' value='...' />
          ...
        </form>
        <script>window.onload = function() { document.forms[0].submit(); }</script>

    Returns OidcFormPost if code+state are present, else None.
    """
    soup = BeautifulSoup(html, "html.parser")
    for form in soup.find_all("form"):
        action = form.get("action", "")
        if "signin-oidc" not in action and "callback" not in action.lower():
            continue

        fields: Dict[str, str] = {}
        for inp in form.find_all("input", {"type": "hidden"}):
            name = inp.get("name")
            if name:
                fields[name] = inp.get("value", "")

        if "code" in fields and "state" in fields:
            logger.info(
                "OIDC form_post detected. Action=%s  Fields=%s",
                action, list(fields.keys()),
            )
            return OidcFormPost(action_url=action, fields=fields)

    return None


def contains_mfa_indicators(html: str) -> bool:
    """Heuristic check for MFA challenge pages."""
    patterns = [
        r"Two[-\s]?Factor",
        r"Authenticator",
        r"verification code",
        r"Enter.*code",
        r"Approve.*sign[-\s]?in",
        r"SMS.*code",
    ]
    return any(re.search(p, html, flags=re.IGNORECASE) for p in patterns)


def get_tenant_slug_from_host(host: str) -> str:
    """'fortisfranchise.restaurant365.com'  →  'fortisfranchise'"""
    return host.split(".", 1)[0] if "." in host else host


# ─────────────────────────────────────────────
#  OIDC / PKCE helpers
# ─────────────────────────────────────────────

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def generate_code_verifier(length: int = 64) -> str:
    """Generate a high-entropy PKCE code_verifier (RFC 7636)."""
    return _b64url(os.urandom(length))


def generate_code_challenge(code_verifier: str) -> str:
    """Generate S256 code_challenge from a code_verifier."""
    return _b64url(hashlib.sha256(code_verifier.encode("ascii")).digest())


def generate_state(length: int = 32) -> str:
    return _b64url(os.urandom(length))


def generate_nonce(length: int = 32) -> str:
    return _b64url(os.urandom(length))


def build_identity_login_url(
    tenant_host: str,
    identity_host: str,
    client_id: str,
    scopes: str,
    response_type: str,
    response_mode: str,
    code_challenge: str,
    code_challenge_method: str,
    state: str,
    nonce: str,
    acr_values: str,
) -> str:
    """Construct the Identity login URL wrapping an OIDC authorize callback as ReturnUrl."""
    authorize_query = urlencode({
        "client_id": client_id,
        "redirect_uri": f"https://{tenant_host}/NetCore/signin-oidc",
        "response_type": response_type,
        "scope": scopes,
        "code_challenge": code_challenge,
        "code_challenge_method": code_challenge_method,
        "response_mode": response_mode,
        "nonce": nonce,
        "acr_values": acr_values,
        "state": state,
        "x-client-SKU": "ID_NET8_0",
        "x-client-ver": "7.7.1.0",
    })
    return_url = f"/connect/authorize/callback?{authorize_query}"
    return f"https://{identity_host}/Account/Login?ReturnUrl={quote(return_url, safe='')}"
