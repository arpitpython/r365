"""Chart of accounts for Fortis Franchise — GL Account Detail Export.
Extracted from browser RunAndExport payload. SSRS requires the full
account list explicitly; selectAll:true alone is not sufficient.
"""

# fmt: off
GL_ACCOUNT_SELECTED_ITEMS = [
    {
        "display": "40000 - Total Products",
        "value": "82261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40100 - Total Mathanasium Program Fees",
        "value": "83261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40101 - Program Fees",
        "value": "8A261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40102 - Program Fees - Deferred Revenue",
        "value": "8B261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40103 - Program Fees - Accrued",
        "value": "ECA646DE-E98E-45F6-BBC2-99BB228B332D",
        "wanted": False
    },
    {
        "display": "40200 - Total Private Lessons",
        "value": "84261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40201 - Private Lessons",
        "value": "8C261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40202 - Private Lessons - Deferred Revenue",
        "value": "8D261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40300 - Total Summer / Short-Term Programs",
        "value": "85261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40301 - Summer / Short-Term Programs",
        "value": "8E261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40302 - Summer / Short-Term Programs - Deferred Revenue",
        "value": "8F261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40400 - Total Early Childhood Programs",
        "value": "86261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40401 - Early Childhood Programs",
        "value": "E0E1EF12-DAEF-47AA-9E1E-B8A71FB1517E",
        "wanted": False
    },
    {
        "display": "40500 - Total Other Programs",
        "value": "87261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40501 - Step Up / Grant Revenue",
        "value": "047247D3-1863-4407-BA29-0C61A6D78B9E",
        "wanted": False
    },
    {
        "display": "40600 - Total Testing & Registration",
        "value": "88261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40601 - Assessment Fees",
        "value": "90261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40602 - Registration Fees",
        "value": "91261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "40700 - Total Other Income",
        "value": "89261133-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50000 - Total Cost of Inventory",
        "value": "0EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50100 - Total Center Payroll",
        "value": "0FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50101 - Payroll - Instructor - Wages",
        "value": "6BCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50102 - Payroll - Instructor - Taxes",
        "value": "6CCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50103 - Payroll - Instructor - Benefits",
        "value": "6DCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50104 - Payroll - Instructor - Retirement",
        "value": "66C22E1C-0F4F-42B0-A7A5-50C1FE958AE5",
        "wanted": False
    },
    {
        "display": "50105 - Payroll - Instructor - Bonus",
        "value": "F6E5AC47-BE6D-4315-80DC-175B2EEDD0DE",
        "wanted": False
    },
    {
        "display": "50111 - Payroll - Associate Center Director - Wages",
        "value": "6ECAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50112 - Payroll - Associate Center Director - Taxes",
        "value": "6FCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50113 - Payroll - Associate Center Director - Benefits",
        "value": "70CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50114 - Payroll - Associate Center Director - Retirement",
        "value": "71CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50115 - Payroll - Associate Center Director - Bonus",
        "value": "72CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50121 - Payroll - Center Director - Wages",
        "value": "73CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50122 - Payroll - Center Director - Taxes",
        "value": "74CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50123 - Payroll - Center Director - Benefits",
        "value": "75CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50124 - Payroll - Center Director - Retirement",
        "value": "76CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50125 - Payroll - Center Director - Bonus",
        "value": "77CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50131 - Payroll - Call Center Agent - Wages",
        "value": "78CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50132 - Payroll - Call Center Agent - Taxes",
        "value": "79CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50133 - Payroll - Call Center Agent - Benefits",
        "value": "7ACAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50134 - Payroll - Call Center Agent - Retirement",
        "value": "7BCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50135 - Payroll - Call Center Agent - Bonus",
        "value": "7CCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50141 - Payroll - Call Center Manager - Wages",
        "value": "7DCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50142 - Payroll - Call Center Manager - Taxes",
        "value": "7ECAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50143 - Payroll - Call Center Manager - Benefits",
        "value": "7FCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50144 - Payroll - Call Center Manager - Retirement",
        "value": "80CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50145 - Payroll - Call Center Manager - Bonus",
        "value": "81CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50151 - Payroll - Regional Education - Wages",
        "value": "82CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50152 - Payroll - Regional Education - Taxes",
        "value": "83CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50153 - Payroll - Regional Education - Benefits",
        "value": "84CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50154 - Payroll - Regional Education - Retirement",
        "value": "85CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50155 - Payroll - Regional Education - Bonus",
        "value": "86CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50161 - Payroll - District Manager - Wages",
        "value": "87CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50162 - Payroll - District Manager - Taxes",
        "value": "88CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50163 - Payroll - District Manager - Benefits",
        "value": "89CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50164 - Payroll - District Manager - Retirement",
        "value": "8ACAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50165 - Payroll - District Manager - Bonus",
        "value": "8BCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50171 - Payroll - Marketing - Wages",
        "value": "8CCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50172 - Payroll - Marketing - Taxes",
        "value": "8DCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50173 - Payroll - Marketing - Benefits",
        "value": "8ECAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50174 - Payroll - Marketing - Retirement",
        "value": "8FCAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50175 - Payroll - Marketing - Bonus",
        "value": "90CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50181 - Payroll - G&A - Wages",
        "value": "91CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50182 - Payroll - G&A - Taxes",
        "value": "92CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50183 - Payroll - G&A - Benefits",
        "value": "93CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50184 - Payroll - G&A - Retirement",
        "value": "94CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50185 - Payroll - G&A - Bonus",
        "value": "95CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50186 - G&A Severance",
        "value": "9692E7B1-0C04-46A9-B35A-4F7EE4EC5E79",
        "wanted": False
    },
    {
        "display": "50199 - Payroll Service Fees",
        "value": "96CAB1A4-CBCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50200 - Total Royalty Expense",
        "value": "14BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50201 - Royalties",
        "value": "5EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50202 - Royalty Rebates",
        "value": "5FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50203 - Royalties - HQ Marketing Royalty",
        "value": "8F88F45B-B8F1-44F8-B6E6-636007E159F2",
        "wanted": False
    },
    {
        "display": "50204 - Royalties - HQ Marketing Fee",
        "value": "63BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "50205 - Royalties - HQ Tech Fee",
        "value": "64BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60000 - Total Marketing Expenses",
        "value": "13BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60005 - Marketing - Visibility Tactics",
        "value": "60BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60010 - Marketing - Print Materials",
        "value": "61BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60020 - Marketing - School Activities",
        "value": "62BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60030 - Marketing - Co-Spend Activities",
        "value": "65BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60040 - Marketing - Internet & Online",
        "value": "66BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60065 - Marketing - Organization Memberships",
        "value": "67BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60070 - Marketing - Special Events",
        "value": "68BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60080 - Marketing - Other",
        "value": "69BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60085 - Marketing - Employee Supplies",
        "value": "6ABB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60090 - Marketing - Referral Rewards",
        "value": "6BBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60095 - Supplies - Reward Cabinet Supplies",
        "value": "6CBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60096 - Supplies - Reward Cabinet Gift Cards",
        "value": "6DBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60100 - Total Auto Expense",
        "value": "15BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60101 - Credit Card Processing Fees",
        "value": "75BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60200 - Total Bank Fees",
        "value": "1BBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60201 - Computer and Software Expense",
        "value": "72BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60202 - Call Center Software",
        "value": "73BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60203 - Printer Lease",
        "value": "74BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60300 - Total Software and Internet Expenses",
        "value": "1CBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60301 - Management Training Program",
        "value": "81BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60302 - Hiring Expense",
        "value": "82BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60303 - Background Checks",
        "value": "83BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60304 - Job Advertising",
        "value": "84BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60305 - Employement Testing",
        "value": "85BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60306 - Relocation",
        "value": "F019B99C-BF03-4163-A5BB-1A78ED15DD2F",
        "wanted": False
    },
    {
        "display": "60400 - Total Credit Card Processing Fees",
        "value": "1DBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60401 - Auto Reimbursement",
        "value": "6EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60402 - Tolls",
        "value": "6FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60403 - Other Auto Expenses",
        "value": "70BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60500 - Total Donations Expense",
        "value": "1EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60600 - Total Dues & Subscriptions",
        "value": "1FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60800 - Total Insurance Expense",
        "value": "20BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "60900 - Total Interest Expense",
        "value": "12BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61000 - Total Licenses & Permits",
        "value": "21BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61001 - Bank Fees",
        "value": "71BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61003 - Donations and Contributions",
        "value": "76BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61005 - Dues & Subscriptions",
        "value": "77BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61007 - Licenses & Permits",
        "value": "7ABB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61009 - Office Supplies",
        "value": "7BBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61011 - Postage and Shipping",
        "value": "7CBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61013 - Printing and Copies",
        "value": "7DBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61200 - Total Office Supplies",
        "value": "22BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61500 - Total Professional Fees",
        "value": "23BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61550 - Total Recruitment Expense",
        "value": "25BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61600 - Total Occupancy Expense",
        "value": "16BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61700 - Total Repairs & Maintenance Expense",
        "value": "17BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "61800 - Total Taxes Expense",
        "value": "11BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "62000 - Total Travel & Entertainment Expense",
        "value": "18BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "62100 - Total Utilities",
        "value": "19BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "62300 - Total Other Expenses",
        "value": "24BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "62500 - Total Depreciation Expense",
        "value": "10BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "66001 - Center Visit Travel",
        "value": "90BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "66005 - Travel Meals",
        "value": "92BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "66009 - Annual Convention Travel",
        "value": "93BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "66015 - Employee Incentives",
        "value": "94BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "67001 - Repairs and Maintenance - Repairs",
        "value": "8DBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "67002 - Repairs and Maintenance - Maintenance",
        "value": "8EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "67003 - Repairs and Maintenance - Cleaning",
        "value": "8FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68001 - Base Rent",
        "value": "86BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68002 - CAM",
        "value": "87BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68003 - Occupancy Sales Tax",
        "value": "88BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68004 - Property Tax",
        "value": "89BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68005 - Rent Lease Expense",
        "value": "69B84E5C-FB2F-474E-B027-DAFC0F92B941",
        "wanted": False
    },
    {
        "display": "68008 - Storage Rent",
        "value": "8ABB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68009 - Corporate Apartment Rent",
        "value": "8BBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68010 - Deferred Rent Adjustment",
        "value": "8CBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68011 - Lease Insurance",
        "value": "264A9EC8-C1B4-4F9C-84C1-65ABF54506AB",
        "wanted": False
    },
    {
        "display": "68101 - Electric",
        "value": "95BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68102 - Gas",
        "value": "96BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68103 - Water",
        "value": "97BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68106 - Trash",
        "value": "98BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68107 - Landscaping",
        "value": "99BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68108 - Pest Control",
        "value": "9ABB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68109 - Security",
        "value": "9BBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68110 - Telephone / Internet",
        "value": "9CBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68201 - Insurance Expense",
        "value": "78BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "68202 - Insurance - Workers Comp",
        "value": "79BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "69501 - Professional Fees - Accounting",
        "value": "7EBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "69502 - Professional Fees - Legal",
        "value": "7FBB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "69505 - Professional Fees - Audit & Tax",
        "value": "80BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "70001 - Management Fees (SnapDragon)",
        "value": "25166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "70002 - Board Fees",
        "value": "DE5FBF83-B33B-4233-B97C-9D5338A83146",
        "wanted": False
    },
    {
        "display": "70003 - Board Travel Expenses",
        "value": "91BB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "71000 - Total Pre-Opening Expenses",
        "value": "1ABB99EF-01CD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "71001 - Pre-Opening Labor",
        "value": "29166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "71002 - Pre-Opening Rent",
        "value": "2A166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "71003 - Pre-Opening Other",
        "value": "2B166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "75001 - Depreciation Expense",
        "value": "27166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "75002 - Amortization Expense",
        "value": "28166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "76001 - Interest Expense",
        "value": "23166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "76002 - Interest Expense - Amort of DFF",
        "value": "FB3A8A94-9914-4DBF-82AB-112165564F77",
        "wanted": False
    },
    {
        "display": "77001 - Taxes",
        "value": "24166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "80001 - Interest Income",
        "value": "20166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "80002 - Rent Income",
        "value": "21166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "80003 - Call Center Income",
        "value": "22166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "80004 - Other Misc. Income / Expense",
        "value": "F22A1521-723A-4BC1-A1F1-11EF81D4E950",
        "wanted": False
    },
    {
        "display": "90001 - Gain (Loss) on Sale of Center",
        "value": "26166D78-CCCD-EF11-9976-6045BD34EBC5",
        "wanted": False
    },
    {
        "display": "99999 - Suspense",
        "value": "7D185E87-8B58-43A8-8D0E-BEBEB5556BAF",
        "wanted": False
    }
]
