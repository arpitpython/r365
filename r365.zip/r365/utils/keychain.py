"""
Generic OS keychain manager for desktop applications.

Stores passwords in the OS keychain (Windows Credential Manager,
macOS Keychain, or libsecret on Linux) via the ``keyring`` library.
Passwords are NEVER written to config files or source code.

Drop this single file into any Python desktop project and use::

    from utils.keychain import KeychainManager

    km = KeychainManager("MyApp")
    km.save_password("alice@example.com", "s3cr3t")
    pwd = km.get_password("alice@example.com")

Requirements:
    pip install keyring

No other project-specific dependencies — intentionally self-contained.
"""

from __future__ import annotations

import logging
from typing import Optional

try:
    import keyring
    import keyring.errors
    _KEYRING_AVAILABLE = True
except ImportError:
    _KEYRING_AVAILABLE = False

logger = logging.getLogger(__name__)


class KeyringUnavailableError(RuntimeError):
    """Raised when the keyring backend is not installed or accessible."""


class PasswordNotFoundError(KeyError):
    """Raised when no password is stored for the given username."""


class KeychainManager:
    """
    OS keychain wrapper for securely storing application passwords.

    Args:
        service_name: Unique identifier for this app in the OS keychain.
                      Use a stable, human-readable name — changing it will
                      break existing stored passwords (users must re-enter).

    All methods raise ``KeyringUnavailableError`` if keyring is not installed.
    Passwords are per (service_name, username) pair.
    """

    def __init__(self, service_name: str) -> None:
        self._service = service_name

    # ── Internal ───────────────────────────────────────────────────────────

    def _require_keyring(self) -> None:
        if not _KEYRING_AVAILABLE:
            raise KeyringUnavailableError(
                "The 'keyring' package is not installed. "
                "Run: pip install keyring"
            )

    # ── Public API ─────────────────────────────────────────────────────────

    def save_password(self, username: str, password: str) -> None:
        """
        Store (or update) the password for *username* in the OS keychain.

        Args:
            username: The account name / key to store the password under.
            password: The plaintext password to store securely.
        """
        self._require_keyring()
        keyring.set_password(self._service, username, password)
        logger.info(
            "Password saved to OS keychain  service=%r  user=%r",
            self._service, username,
        )

    def get_password(self, username: str) -> str:
        """
        Retrieve the stored password for *username* from the OS keychain.

        Args:
            username: The account name used when the password was saved.

        Returns:
            The stored plaintext password.

        Raises:
            PasswordNotFoundError   — no password has been stored yet.
            KeyringUnavailableError — keyring backend is missing or broken.
        """
        self._require_keyring()
        try:
            password = keyring.get_password(self._service, username)
        except keyring.errors.KeyringError as exc:
            raise KeyringUnavailableError(
                f"OS keychain access failed for user '{username}': {exc}"
            ) from exc

        if password is None:
            raise PasswordNotFoundError(
                f"No password stored for '{username}' "
                f"(service='{self._service}'). "
                f"Run the credential setup wizard first."
            )
        return password

    def delete_password(self, username: str) -> None:
        """
        Remove the stored password for *username* from the OS keychain.
        Silently ignores the case where no password was stored.
        """
        self._require_keyring()
        try:
            keyring.delete_password(self._service, username)
            logger.info(
                "Password removed from OS keychain  service=%r  user=%r",
                self._service, username,
            )
        except keyring.errors.PasswordDeleteError:
            logger.warning(
                "No stored password to delete  service=%r  user=%r",
                self._service, username,
            )

    def has_password(self, username: str) -> bool:
        """
        Return ``True`` if a password is already stored for *username*.
        Never raises — returns ``False`` on any error (keyring missing, etc.).
        """
        if not _KEYRING_AVAILABLE:
            return False
        try:
            return keyring.get_password(self._service, username) is not None
        except keyring.errors.KeyringError:
            return False
