# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A Python tool for automating GL Account Detail report downloads from Restaurant365 (R365). Supports both a CLI entry point and a Flet-based desktop GUI. Authentication uses a multi-step OIDC/OAuth2 with PKCE flow against R365's IdentityServer.

## Running the Application

```bash
# First-time credential setup (stores password in OS keychain)
python -m app.credentials setup

# CLI report download
python run_auth_test.py
python run_auth_test.py --start 2025-01-01 --end 2025-12-31 --out ./downloads/q1.xlsx

# Desktop GUI
python -m app.ui.app
```

## Environment Configuration

Copy `.env.example` to `.env` and adjust if needed. Key variables:
- `R365_IDENTITY_HOST` — identity server hostname
- `R365_TIMEOUT_SECONDS`, `R365_MAX_RETRIES`, `R365_BACKOFF_FACTOR` — HTTP retry settings
- `R365_VERIFY_TLS` — TLS verification toggle

## Project Structure

```
app/
├── auth.py               — R365Authenticator (OIDC/PKCE login flow)
├── config.py             — Settings, Tenant, Credential dataclasses; TENANTS dict
├── credentials.py        — R365-specific wrapper over utils/keychain.KeychainManager
├── exceptions.py         — All custom exception types
├── types.py              — ReportRequest, ReportResult, AuthInputs, AuthResult, etc.
├── utils.py              — HTTP session factory, HTML parsing, PKCE helpers
└── reports/              — One file per report; helpers prefixed with _
    ├── __init__.py           exports GLAccountDetailExporter
    ├── gl_detail_report.py   GL Account Detail Export (RunAndExport) ← the report
    ├── _reports_page.py      helper: fetches /ServiceStack/ReportsPage
    └── _validate_report.py   helper: resolves hidden params via /ServiceStack/ValidateReport

utils/
└── keychain.py           — Generic, project-agnostic OS keychain manager (copyable to any project)

app/ui/
├── app.py                — Flet entry point; splash screen + background credential detection
├── theme.py              — UI colours, spacing, typography constants
├── log_handler.py        — FletLogHandler: batches log lines, flushes every ~150ms
└── view/
    ├── login_view.py     — Login screen with account dropdown + keychain save
    └── report_view.py    — Report download screen; runs download on background thread
```

## Architecture

### Authentication Flow (`app/auth.py`)

`R365Authenticator` implements a multi-step OIDC login:
1. Initiates OIDC flow at the tenant host (e.g., `fortisfranchise.restaurant365.com`)
2. Follows redirect to Identity server (`identity.restaurant365.com`)
3. Parses login form, extracts anti-forgery token, submits credentials
4. Handles `form_post` OIDC response → completes `/NetCore/signin-oidc` callback
5. Optionally handles a second OIDC authorize cycle
6. Bootstraps ServiceStack cookies and injects user-id/display-name cookies
7. Returns an authenticated `Session` object

MFA raises `MfaRequiredError` (not supported). The flow is fragile to upstream HTML changes — `UpstreamChangedError` is raised when expected tokens/forms are missing.

### Report Download Flow (`app/reports/`)

**Adding a new report:** create one new file `app/reports/<report_name>.py` and export its class from `app/reports/__init__.py`. The two helper files (`_reports_page.py`, `_validate_report.py`) are shared infrastructure — do not duplicate them.

`GLAccountDetailExporter` in `gl_detail_report.py` orchestrates three sequential steps:
1. **ReportsPage** (`_reports_page.py`) — fetches live report catalogue from `/ServiceStack/ReportsPage`
2. **ValidateReport** (`_validate_report.py`) — POSTs to `/ServiceStack/ValidateReport` to resolve tenant-specific server-side parameters: database name, SQL Server host, timezone code, UTC offset, and full chart of accounts
3. **RunAndExport** — POSTs to `/NetCore/SsrsReport/RunAndExport` with the complete payload, then streams the Excel file from the returned Azure Blob Storage SAS URL

### Tenant & Credential Configuration (`app/config.py`)

Tenants are defined in `load_tenants()` as `Tenant` dataclasses containing subdomain host, app path, and a dict of `Credential` objects (username, user_id, display_name). Passwords are never stored in source — they are stored in the OS keychain via `CredentialManager` (`app/credentials.py`) backed by `utils/keychain.py`.

Keychain service name: `"R365DesktopTool"` — changing this breaks existing stored passwords.

### Generic Keychain Utility (`utils/keychain.py`)

`KeychainManager(service_name)` is intentionally self-contained with no project-specific imports. Copy it to any desktop project:

```python
from utils.keychain import KeychainManager
km = KeychainManager("MyOtherApp")
km.save_password("user@example.com", "s3cr3t")
```

### Desktop UI (`app/ui/`)

Built with [Flet](https://flet.dev/).

**Startup speed** — `app.py` shows a loading splash immediately then calls `page.run_thread(_startup_route, page)` to detect OS keychain credentials in a background thread. The window is never blank.

**UI responsiveness during download** — `report_view.py` runs the entire download (auth + report) via `page.run_thread()`. `FletLogHandler` buffers incoming log records and flushes them to the UI in a single `page.update()` every 150ms via a `threading.Timer`, preventing `page.update()` storms from freezing the UI. Status messages (`add_app_message`) bypass the buffer for immediate display.

### Key Types and Exceptions

**Types** (`app/types.py`): `AuthInputs`, `AuthResult`, `LoginFormInfo`, `OidcFormPost`, `ReportRequest`, `ReportResult`

**Exceptions** (`app/exceptions.py`): `AuthError`, `InvalidCredentialsError`, `MfaRequiredError`, `AntiForgeryTokenNotFound`, `UpstreamChangedError`, `OidcCallbackError`, `SessionVerificationError`, `ReportError`, `ReportExportFailed`, `ReportDownloadFailed`

## Dependencies

Runtime dependencies not fully in `requirements.txt` — install manually if missing:

```bash
pip install flet keyring
pip install -r requirements.txt
```

## No Test Infrastructure

No automated tests. Manual testing via `run_auth_test.py` (CLI) or `python -m app.ui.app` (GUI).
